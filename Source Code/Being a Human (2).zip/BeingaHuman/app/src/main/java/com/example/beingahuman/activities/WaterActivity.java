package com.example.beingahuman.activities;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.preference.PreferenceManager;

import com.example.beingahuman.R;
import com.example.beingahuman.classes.ManageDrawables;
import com.example.beingahuman.classes.Notify;
import com.example.beingahuman.database.DatabaseHelper;
import com.example.beingahuman.services.NotificationService;

import java.sql.Time;
import java.util.Calendar;
import java.util.Date;

public class WaterActivity extends AppCompatActivity {

    //variable used to hold the text field that displays the water amount
    TextView waterAmountText,waterGoalText;
    //variable used to connect to the progress bar
    ProgressBar waterProgressBar;
    //variable used to connect to the water bottle image that is used as a button
    RelativeLayout waterBottle;
    //variable used to connect to the weekly report button
    Button weeklyReportButton;
    //variable used to hold the current containerSize
    float containerSize;
    //variable used to hold the goal amount
    float goal;
    //variable used to define the amount that the progress bar should advance based on the container size
    float incrementCount;
    //variable used to hold the currentAmount of water that has been drank for the day
    float currentAmount;

    //For recurring notifications
    private AlarmManager alarmMgr;
    private PendingIntent alarmIntent;

    SharedPreferences pref;

    TextView recommendedGoal;


    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_water);

        Window window = this.getWindow();
        View vieww = window.getDecorView();

        new WindowInsetsControllerCompat(window,vieww).setAppearanceLightStatusBars(true);

        //stores the default shared preferences into pref
        pref = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor edit = pref.edit();


        ManageDrawables.setDefaultDayOfWeekColors(this, Color.GRAY);


        Date date = new Date();
        if(pref.getString("date", "empty").equals("empty")) {
            edit.putString("date", date.toString());
        }

        if(pref.getString("date", "empty").compareTo(date.toString()) < 0) {
            edit.putString("date", date.toString());
            edit.putFloat("current_amount", 0);
        }


        recommendedGoal = findViewById(R.id.recommended_goal);

        //calls addNotification() method to create a new notification if the user has reminders on
        if(pref.getBoolean("switch", false)) {
            addNotification();
        }

        waterAmountText = findViewById(R.id.waterAmount);
        waterGoalText = findViewById(R.id.goal_text);
        waterProgressBar = (ProgressBar) findViewById(R.id.progress);
        waterBottle = findViewById(R.id.WaterBottle);
        weeklyReportButton = findViewById(R.id.weeklyReport);

        //defines values based on the default shared preferences
        containerSize = pref.getFloat("container_size", 1);
        goal = Float.parseFloat(pref.getString("goal", "8"));
        incrementCount = (containerSize/goal) * 100;
        currentAmount = pref.getFloat("current_amount", 0);

        waterProgressBar.setProgress((int)((currentAmount / goal) * 100));

        //sets the text above the waterProgressBar to the currentAmount next to the goal value
        waterAmountText.setText(currentAmount + " Glasses / " + goal + " Glasses");

        if(currentAmount >= 8){
            waterGoalText.setText("Your daily water goal is completed ✔️");
        }

        //creates a OnClickListener for the weeklyReportButton that starts the WeeklyReport activity
        //when the button is clicked
        weeklyReportButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //code to update the circles to the right colors based on the database goes here
                DatabaseHelper db = new DatabaseHelper(WaterActivity.this);
                int[] completeDays = db.getCompleteDays();
                //resets colors before the colors are updated from the database
                ManageDrawables.setDefaultDayOfWeekColors(WaterActivity.this, Color.GRAY);
                ManageDrawables.setDayOfWeekColors(completeDays, WaterActivity.this);
                Intent intent = new Intent(WaterActivity.this, WaterWeeklyReport.class);
                startActivity(intent);
            }
        });


    }

    public void waterOnClick(View view) {
        //increments the waterProgressBar by the amount determined by the container size
        waterProgressBar.incrementProgressBy(Math.round(incrementCount));
        //increases the currentAmount based on the current containerSize
        currentAmount += Math.round(containerSize);
        waterAmountText.setText(currentAmount + " Glasses / " + goal + " Glasses");
        if(currentAmount >= 8){
            waterGoalText.setText("Your daily water goal is completed ✔️");
        }
        SharedPreferences.Editor edit = pref.edit();
        edit.putFloat("current_amount", currentAmount);
        edit.apply();

        java.util.Date utilDate = new java.util.Date();
        java.sql.Date date = new java.sql.Date(utilDate.getTime());
        Time time = new Time(utilDate.getTime());
        DatabaseHelper db = new DatabaseHelper(this);
        db.insertData(time, date, goal, currentAmount, containerSize);
    }

    public void waterRemoveOnClick(View view) {
        currentAmount -= Math.round(containerSize);
        if(currentAmount <=0){
            currentAmount = 0;
        }
        waterProgressBar.setProgress((int)((currentAmount / goal) * 100));
        waterAmountText.setText(currentAmount + " Glasses / " + goal + " Glasses");
        if(currentAmount >= 8){
            waterGoalText.setText("Your daily water goal is completed ✔️");
        }else {
            waterGoalText.setText("️");
        }
        SharedPreferences.Editor edit = pref.edit();
        edit.putFloat("current_amount", currentAmount);
        edit.apply();

        java.util.Date utilDate = new java.util.Date();
        java.sql.Date date = new java.sql.Date(utilDate.getTime());
        Time time = new Time(utilDate.getTime());
        DatabaseHelper db = new DatabaseHelper(this);
        db.insertData(time, date, goal, currentAmount, containerSize);
    }


    private void addNotification() {
        alarmMgr = (AlarmManager)getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(this, Notify.class);
        alarmIntent = PendingIntent.getBroadcast(this, 0, intent, 0);

        //Reads in the current date and time of the system
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());
        //sets the time of notification to start at 8am
        calendar.set(Calendar.HOUR_OF_DAY, 2);
        calendar.set(Calendar.MINUTE, 15);

        //starts a repeating notification for every 30 minutes
        alarmMgr.setRepeating(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), 1000*60, alarmIntent);
    }

    @Override
    protected void onStop() {

        super.onStop();

        startService(new Intent(this, NotificationService.class));
    }


}

