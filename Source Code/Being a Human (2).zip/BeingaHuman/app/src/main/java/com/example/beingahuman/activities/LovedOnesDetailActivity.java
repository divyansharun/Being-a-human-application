package com.example.beingahuman.activities;

import android.content.Context;
import android.content.Intent;

import androidx.fragment.app.Fragment;

import com.example.beingahuman.fragments.ContactViewFragment;

import java.util.UUID;


public class LovedOnesDetailActivity extends SingleFragmentActivity {

    private static final String EXTRA_CONTACT_ID =
            "com.example.beingahuman.activities.crime_id";

    public static Intent newIntent(Context packageContext, UUID contactId) {
        Intent intent = new Intent(packageContext, LovedOnesDetailActivity.class);
        intent.putExtra(EXTRA_CONTACT_ID, contactId);
        return intent;
    }

    @Override
    protected Fragment createFragment() {
        UUID contactId = (UUID) getIntent()
                .getSerializableExtra(EXTRA_CONTACT_ID);
        return ContactViewFragment.newInstance(contactId);
    }

}
