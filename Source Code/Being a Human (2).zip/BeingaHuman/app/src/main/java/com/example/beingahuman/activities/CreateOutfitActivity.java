package com.example.beingahuman.activities;

import android.Manifest;
import android.app.AlertDialog;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.WindowInsetsControllerCompat;

import com.bumptech.glide.Glide;
import com.example.beingahuman.models.Wear;
import com.example.beingahuman.R;

import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

import static android.R.layout.simple_spinner_item;
import static android.widget.Toast.LENGTH_SHORT;
import static com.example.beingahuman.Utils.WearTypes.BOTTOMS;
import static com.example.beingahuman.Utils.WearTypes.FACE_ACCESSORY;
import static com.example.beingahuman.Utils.WearTypes.HAND_ARM_ACCESSORY;
import static com.example.beingahuman.Utils.WearTypes.HAT;
import static com.example.beingahuman.Utils.WearTypes.JACKET;
import static com.example.beingahuman.Utils.WearTypes.SHOES;
import static com.example.beingahuman.Utils.WearTypes.TOP;
import static com.example.beingahuman.Utils.convertBytesToBitmap;

public class CreateOutfitActivity extends AppCompatActivity {
    private static final int MY_CAMERA_REQUEST_CODE = 100;
    private int hatId;
    private int faceId;
    private int topId;
    private int jacketId;
    private int handArmId;
    private int bottomsId;
    private int shoesId;
    private EditText outfitNameEditText;
    private ImageView hatImageButton;
    private ImageView faceImageButton;
    private ImageView topImageButton;
    private ImageView jacketImageButton;
    private ImageView handArmImageButton;
    private ImageView bottomsImageButton;
    private ImageView shoesImageButton;
    private ArrayList<Wear> wears;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initialize();
    }

    private void initialize() {
        setContentView(R.layout.activity_create_outfit);

        Window window = this.getWindow();
        View vieww = window.getDecorView();

        new WindowInsetsControllerCompat(window,vieww).setAppearanceLightStatusBars(true);

        ImageView back_button = findViewById(R.id.back_button);

        back_button.setOnClickListener(view -> {
            onBackPressed();
        });

        hatId = -1;
        faceId = -1;
        topId = -1;
        jacketId = -1;
        handArmId = -1;
        bottomsId = -1;
        shoesId = -1;

        wears = new ArrayList<>();
        fetchWears();

        outfitNameEditText = findViewById(R.id.outfitNameEditText);
        hatImageButton = findViewById(R.id.hatImageButton);
        faceImageButton = findViewById(R.id.faceImageButton);
        topImageButton = findViewById(R.id.topImageButton);
        jacketImageButton = findViewById(R.id.jacketImageButton);
        handArmImageButton = findViewById(R.id.handArmImageButton);
        bottomsImageButton = findViewById(R.id.bottomsImageButton);
        shoesImageButton = findViewById(R.id.shoesImageButton);
        Button saveOutfitButton = findViewById(R.id.saveOutfitButton);

        hatImageButton.setOnClickListener(_v -> showSelectWearPopup(HAT));
        faceImageButton.setOnClickListener(_v -> showSelectWearPopup(FACE_ACCESSORY));
        topImageButton.setOnClickListener(_v -> showSelectWearPopup(TOP));
        jacketImageButton.setOnClickListener(_v -> showSelectWearPopup(JACKET));
        handArmImageButton.setOnClickListener(_v -> showSelectWearPopup(HAND_ARM_ACCESSORY));
        bottomsImageButton.setOnClickListener(_v -> showSelectWearPopup(BOTTOMS));
        shoesImageButton.setOnClickListener(_v -> showSelectWearPopup(SHOES));
        saveOutfitButton.setOnClickListener(_v -> saveOutfit());

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.CAMERA}, MY_CAMERA_REQUEST_CODE);
            }
        }
    }

    private void showSelectWearPopup(int wearType) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Choose Outfit");

        ArrayList<String> items = new ArrayList<>();

        for (Wear wear : wears)
            if (wear.getType() == wearType) items.add(wear.getName() + " - " + wear.getId());

        Spinner input = new Spinner(this);
        input.setPadding(20, 20, 20, 20);

        input.setAdapter(new ArrayAdapter<>(this, simple_spinner_item, items));
        builder.setView(input);

        builder.setPositiveButton("Ok", (_d, _w) -> {
            try {
                assignWear(input.getSelectedItem().toString(), wearType);
            } catch (ExecutionException e) {
                e.printStackTrace();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });
        builder.setNegativeButton("Cancel", (dialog, _w) -> dialog.cancel());

        builder.show();
    }


    private void assignWear(String item, int wearType) throws ExecutionException, InterruptedException {
        int id;
        String idString = item.split(" - ")[1];

        if (idString != null) id = Integer.parseInt(idString);
        else return;

        Wear wear = null;
        for (Wear i : wears)
            if (i.getId() == id) wear = i;

        if (wear == null) return;

        if (wearType == HAT) {
            hatId = id;
            Glide.with(this).load(wear.getPhoto()).into(hatImageButton);
        } else if (wearType == FACE_ACCESSORY) {
            faceId = id;
            Glide.with(this).load(wear.getPhoto()).into(faceImageButton);
        } else if (wearType == TOP) {
            topId = id;
            Glide.with(this).load(wear.getPhoto()).into(topImageButton);
        } else if (wearType == JACKET) {
            jacketId = id;
            Glide.with(this).load(wear.getPhoto()).into(jacketImageButton);
        } else if (wearType == HAND_ARM_ACCESSORY) {
            handArmId = id;
            Glide.with(this).load(wear.getPhoto()).into(handArmImageButton);
        } else if (wearType == BOTTOMS) {
            bottomsId = id;
            Glide.with(this).load(wear.getPhoto()).into(bottomsImageButton);
        } else if (wearType == SHOES) {
            shoesId = id;
            Glide.with(this).load(wear.getPhoto()).into(shoesImageButton);
        }
    }

    private void saveOutfit() {
        String name = outfitNameEditText.getText().toString();

        String errorMessage = getErrorMessage(name, hatId, faceId, topId, jacketId, handArmId, bottomsId, shoesId);
        if (errorMessage != null) {
            Toast.makeText(getApplicationContext(), errorMessage, LENGTH_SHORT).show();
            return;
        }

        SQLiteDatabase db = null;
        String message = null;
        try {
            db = openOrCreateDatabase("Database", MODE_PRIVATE, null);
            String sql = "INSERT INTO outfits (name, hat, face_accessory, top, jacket, hand_arm_accessory, bottoms, shoes) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            SQLiteStatement statement = db.compileStatement(sql);
            statement.bindString(1, name);
            statement.bindLong(2, hatId);
            statement.bindLong(3, faceId);
            statement.bindLong(4, topId);
            statement.bindLong(5, jacketId);
            statement.bindLong(6, handArmId);
            statement.bindLong(7, bottomsId);
            statement.bindLong(8, shoesId);
            statement.executeInsert();
            message = "Kombin başarıyla eklendi!";
        } catch (Exception e) {
            e.printStackTrace();
            message = "Bir hata oluştu!";
        } finally {
            if (db != null) db.close();
            Toast.makeText(getApplicationContext(), message, LENGTH_SHORT).show();
            finish();
        }
    }

    private String getErrorMessage(String name, int hat, int face, int top, int jacket, int handArm, int bottoms, int shoes) {
        if (name == null || name.length() < 0) return "Lütfen bir isim giriniz!";
        if (hat < 0) return "Lütfen bir şapka seçiniz!";
        if (face < 0) return "Lütfen bir yüz - yüz aksesuarı seçiniz!";
        if (top < 0) return "Lütfen bir üst seçiniz!";
        if (jacket < 0) return "Lütfen bir ceket seçiniz!";
        if (handArm < 0) return "Lütfen bir el-kol aksesuarı seçiniz!";
        if (bottoms < 0) return "Lütfen bir alt seçiniz!";
        if (shoes < 0) return "Lütfen bir ayakkabı seçiniz!";
        return null;
    }

    private void fetchWears() {
        SQLiteDatabase db = null;
        Cursor cursor = null;
        try {
            db = openOrCreateDatabase("Database", MODE_PRIVATE, null);
            cursor = db.rawQuery("SELECT * FROM wears", null);
            while (cursor.moveToNext()) {
                int id = cursor.getInt(cursor.getColumnIndex("id"));
                String name = cursor.getString(cursor.getColumnIndex("name"));
                String color = cursor.getString(cursor.getColumnIndex("color"));
                String pattern = cursor.getString(cursor.getColumnIndex("pattern"));
                int type = cursor.getInt(cursor.getColumnIndex("type"));
                float price = cursor.getFloat(cursor.getColumnIndex("price"));
                String datePurchased = cursor.getString(cursor.getColumnIndex("date_purchased"));
                String photo = cursor.getString(cursor.getColumnIndex("photo"));
                Wear wear = new Wear(id, name, color, pattern, type, price, datePurchased, photo);
                System.out.println("ITEM: " + name + " " + id);
                wears.add(wear);
            }
        } catch (Exception e) {
            Toast.makeText(this, "Bir hata oluştu!", LENGTH_SHORT);
        } finally {
            if (cursor != null) cursor.close();
            if (db != null) db.close();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == MY_CAMERA_REQUEST_CODE) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "camera permission granted", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "camera permission denied", Toast.LENGTH_LONG).show();
            }
        }
    }

}