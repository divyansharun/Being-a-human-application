package com.example.beingahuman.activities;

import android.app.AlertDialog;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.beingahuman.adapters.DrawerRecyclerAdapter;
import com.example.beingahuman.models.Drawer;
import com.example.beingahuman.R;

import java.util.ArrayList;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;
import static android.widget.Toast.LENGTH_SHORT;

public class DrawersActivity extends AppCompatActivity {
    private RecyclerView drawersRecycler;
    private TextView noItemText;
    private ArrayList<Drawer> drawers;
    ImageView add_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initialize();
    }

    private void initialize() {
        setContentView(R.layout.activity_drawers);

        Window window = this.getWindow();
        View vieww = window.getDecorView();

        new WindowInsetsControllerCompat(window,vieww).setAppearanceLightStatusBars(true);

        drawersRecycler = findViewById(R.id.drawersRecyclerView);
        noItemText = findViewById(R.id.noItemText);
        add_button = findViewById(R.id.add_button);

        add_button.setOnClickListener(view -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Create Drawer");

            EditText input = new EditText(this);
            input.setHint("Drawer Name");
            input.setPadding(20, 20, 20, 20);
            builder.setView(input);

            builder.setPositiveButton("Create", (_d, _w) -> createDrawer(input.getText().toString()));
            builder.setNegativeButton("Cancel", (dialog, _w) -> dialog.cancel());

            builder.show();
        } );

        ImageView back_button = findViewById(R.id.back_button);

        back_button.setOnClickListener(view -> {
            onBackPressed();
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        fetchDrawers();
    }


//    @Override
//    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
//        AlertDialog.Builder builder = new AlertDialog.Builder(this);
//        builder.setTitle("Çekmece Oluştur");
//
//        EditText input = new EditText(this);
//        input.setHint("Çekmece Adı");
//        input.setPadding(20, 20, 20, 20);
//        builder.setView(input);
//
//        builder.setPositiveButton("Oluştur", (_d, _w) -> createDrawer(input.getText().toString()));
//        builder.setNegativeButton("İptal", (dialog, _w) -> dialog.cancel());
//
//        builder.show();
//        return true;
//    }

    private void createDrawer(String name) {
        if (name == null || name.length() <= 0) {
            Toast.makeText(getApplicationContext(), "Please enter a drawer name!", LENGTH_SHORT).show();
            return;
        }

        SQLiteDatabase db = null;
        String message = null;
        try {
            db = openOrCreateDatabase("Database", MODE_PRIVATE, null);
            String sql = "INSERT INTO drawers (name) VALUES (?)";
            SQLiteStatement statement = db.compileStatement(sql);
            statement.bindString(1, name);
            statement.executeInsert();
            message = "Drawer added successfully!";
        } catch (Exception e) {
            message = "Something went wrong!";
        } finally {
            if (db != null) db.close();
            Toast.makeText(getApplicationContext(), message, LENGTH_SHORT).show();
            fetchDrawers();
        }
    }

    public void fetchDrawers() {
        drawers = new ArrayList<>();
        SQLiteDatabase db = null;
        Cursor cursor = null;
        try {
            db = openOrCreateDatabase("Database", MODE_PRIVATE, null);
            cursor = db.rawQuery("SELECT * FROM drawers", null);

            while (cursor.moveToNext()) {
                int id = cursor.getInt(cursor.getColumnIndex("id"));
                String name = cursor.getString(cursor.getColumnIndex("name"));
                System.out.println("NAME: " + name);
                Drawer drawer = new Drawer(id, name);

                Cursor countCursor = db.rawQuery("SELECT count(*) AS count FROM wears WHERE drawer_id = " + id, null);
                countCursor.moveToFirst();
                int wearCount = countCursor.getInt(countCursor.getColumnIndex("count"));
                countCursor.close();

                drawer.setWearCount(wearCount);
                drawers.add(drawer);
            }
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), "Something went wrong!", LENGTH_SHORT);
        } finally {
            if (cursor != null) cursor.close();
            if (db != null) db.close();
            DrawerRecyclerAdapter adapter = new DrawerRecyclerAdapter(drawers, this);
            drawersRecycler.setAdapter(adapter);
            drawersRecycler.setLayoutManager(new LinearLayoutManager(this));
            adapter.notifyDataSetChanged();
            noItemText.setVisibility(drawers.size() == 0 ? VISIBLE : GONE);
        }
    }
}