package com.example.beingahuman.activities;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.preference.PreferenceManager;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.example.beingahuman.Adapter;
import com.example.beingahuman.R;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.gun0912.tedpermission.PermissionListener;
import com.gun0912.tedpermission.normal.TedPermission;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.util.List;

import static android.content.ContentValues.TAG;
import static android.widget.Toast.LENGTH_SHORT;
import static com.example.beingahuman.Utils.SQLCodes.CREATE_DRAWERS_TABLE;
import static com.example.beingahuman.Utils.SQLCodes.CREATE_EVENTS_TABLE;
import static com.example.beingahuman.Utils.SQLCodes.CREATE_OUTFITS_TABLE;
import static com.example.beingahuman.Utils.SQLCodes.CREATE_WEARS_TABLE;
import static com.example.beingahuman.Utils.SQLCodes.INSERT_DRAWERS_TABLE;
import static com.example.beingahuman.Utils.SQLCodes.INSERT_WEARS_TABLE;
import static com.example.beingahuman.Utils.SQLCodes.INSERT_WEARS_TABLE10;
import static com.example.beingahuman.Utils.SQLCodes.INSERT_WEARS_TABLE11;
import static com.example.beingahuman.Utils.SQLCodes.INSERT_WEARS_TABLE12;
import static com.example.beingahuman.Utils.SQLCodes.INSERT_WEARS_TABLE2;
import static com.example.beingahuman.Utils.SQLCodes.INSERT_WEARS_TABLE3;
import static com.example.beingahuman.Utils.SQLCodes.INSERT_WEARS_TABLE4;
import static com.example.beingahuman.Utils.SQLCodes.INSERT_WEARS_TABLE5;
import static com.example.beingahuman.Utils.SQLCodes.INSERT_WEARS_TABLE6;
import static com.example.beingahuman.Utils.SQLCodes.INSERT_WEARS_TABLE7;
import static com.example.beingahuman.Utils.SQLCodes.INSERT_WEARS_TABLE8;
import static com.example.beingahuman.Utils.SQLCodes.INSERT_WEARS_TABLE9;

public class MainActivity extends AppCompatActivity implements LocationListener {

    RecyclerView recyclerView;
    Adapter adapter;
    public String latitude, longitude;
    protected LocationManager locationManager;
    Location location;
    public static final int MY_PERMISSIONS_REQUEST_LOCATION = 99;
    public static final int MY_CAMERA_REQUEST_CODE = 100;
    ImageView profile_pic,back_button;
    BottomSheetBehavior bottomSheetBehavior, factbottomsheet;
    Intent login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Window window = this.getWindow();
        View vieww = window.getDecorView();

        new WindowInsetsControllerCompat(window,vieww).setAppearanceLightStatusBars(true);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new GridLayoutManager(MainActivity.this, 2));
        adapter = new Adapter(this);
        recyclerView.setAdapter(adapter);
        profile_pic = findViewById(R.id.profile_pic);
        back_button = findViewById(R.id.back_button);
        TextView hello_name = findViewById(R.id.hello_name);
        TextView profile_name = findViewById(R.id.profile_name);
        TextView profile_email = findViewById(R.id.profile_email);
        ImageView profile_img = findViewById(R.id.profile_img);

        View bottomsheet = findViewById(R.id.profile_sheet);
        View bottomsheetfact = findViewById(R.id.bottom_sheet);
        bottomSheetBehavior = BottomSheetBehavior.from(bottomsheet);
        factbottomsheet = BottomSheetBehavior.from(bottomsheetfact);

        back_button.setOnClickListener(view -> bottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED));

        createDatabaseIfNotExists();

        SharedPreferences preferences =  PreferenceManager.getDefaultSharedPreferences(this);
        Boolean is_logged_in = preferences.getBoolean("is_login", false);
        String profile = preferences.getString("p_pic",null);
        String fname = preferences.getString("first_name","User");
        String lname = preferences.getString("last_name","");
        String email = preferences.getString("email","");

        if(is_logged_in) {
            if (profile != null){
                Glide.with(this).load(profile).apply(RequestOptions.circleCropTransform()).into(profile_pic);
                Glide.with(this).load(profile).apply(RequestOptions.circleCropTransform()).into(profile_img);
            }
            hello_name.setText("Hello "+fname+"!");
            profile_name.setText(fname+" "+lname);
            profile_email.setText(email);
            profile_pic.setOnClickListener(view -> bottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED));
        }else{
            login = new Intent(getApplicationContext(), LoginActivity.class);
            profile_pic.setOnClickListener(view -> startActivity(login));
        }

        PermissionListener permissionlistener = new PermissionListener() {
            @Override
            public void onPermissionGranted() {
                Toast.makeText(MainActivity.this, "Permission Granted", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onPermissionDenied(List<String> deniedPermissions) {
                Toast.makeText(MainActivity.this, "Permission Denied\n" + deniedPermissions.toString(), Toast.LENGTH_SHORT).show();
            }


        };

        TedPermission.create()
                .setPermissionListener(permissionlistener)
                .setDeniedMessage("If you reject permission,you can not use some parts of this app\n\nPlease turn on permissions at [Setting] > [Permission]")
                .setPermissions(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.CAMERA, Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.READ_CONTACTS)
                .check();

        checkLocationPermission();

        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
        if (location == null){
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 400, 1, this);
        }else{
            latitude = Double.toString(location.getLatitude());
            longitude = Double.toString(location.getLongitude());
            getJsonData();
        }

        ConstraintLayout bottom_sheet_view = findViewById(R.id.bottom_sheet);

        bottomsheetfact.setOnClickListener(view -> {
            factbottomsheet.setState(BottomSheetBehavior.STATE_EXPANDED);
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onLocationChanged(Location location) {
        latitude = Double.toString(location.getLatitude());
        longitude = Double.toString(location.getLongitude());
        getJsonData();
    }

    @Override
    public void onProviderDisabled(String provider) {
        Log.d("Latitude","disable");
    }

    @Override
    public void onProviderEnabled(String provider) {
        Log.d("Latitude","enable");
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {
        Log.d("Latitude","status");
    }

    public boolean checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.ACCESS_FINE_LOCATION)) {

                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.
                new AlertDialog.Builder(this)
                        .setTitle("Location Needed")
                        .setMessage("We need location to show weather")
                        .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                //Prompt the user once explanation has been shown
                                ActivityCompat.requestPermissions(MainActivity.this,
                                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                                        MY_PERMISSIONS_REQUEST_LOCATION);
                            }
                        })
                        .create()
                        .show();


            } else {
                // No explanation needed, we can request the permission.
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        MY_PERMISSIONS_REQUEST_LOCATION);
            }
            return false;
        } else {
            return true;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_LOCATION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    // permission was granted, yay! Do the
                    // location-related task you need to do.
                    if (ContextCompat.checkSelfPermission(this,
                            Manifest.permission.ACCESS_FINE_LOCATION)
                            == PackageManager.PERMISSION_GRANTED) {

                        //Request location updates:
                        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 400, 1, this);
                    }

                } else {

                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.

                }
                return;
            }
            case MY_CAMERA_REQUEST_CODE: {
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, "camera permission granted", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(this, "camera permission denied", Toast.LENGTH_LONG).show();
                }
            }

        }
    }

    private void getJsonData(){

        String URL = "https://dataservice.accuweather.com/locations/v1/cities/geoposition/search?apikey=QoCCAo0AitHkkP3ERu02mPlf1HNsABgA&q="+latitude+","+longitude+"";
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        JsonObjectRequest objectRequest = new JsonObjectRequest(Request.Method.GET, URL, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                Log.d("TAG", "onResponse: " + response);

                try {
                    String location_key = response.getString("Key");

//                    TextView city_name = (TextView) findViewById(R.id.city);
//                    city_name.setText(response.getString("EnglishName"));

                    Log.d(TAG, "onResponse: "+ location_key);

                    getCityWeather(location_key);

                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });

        requestQueue.add(objectRequest);

    }

    private void getCityWeather(String key){

        String URL = "https://dataservice.accuweather.com/forecasts/v1/daily/1day/"+key+"?apikey=QoCCAo0AitHkkP3ERu02mPlf1HNsABgA&metric=true";
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        JsonObjectRequest objectRequest = new JsonObjectRequest(Request.Method.GET, URL, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                Log.d("TAG", "onResponse: " + response);


                try {
                    JSONArray forecast = response.getJSONArray("DailyForecasts");
                    JSONObject data = forecast.getJSONObject(0);
                    JSONObject dataforecast = data.getJSONObject("Temperature");
                    JSONObject minimum = dataforecast.getJSONObject("Minimum");
                    String value = minimum.getString("Value");
                    String unit = minimum.getString("Unit");

                    Log.d("TAG", "onResponsedata: " + value);
                    TextView temprature = (TextView) findViewById(R.id.temprature);
                    temprature.setText(value+"°"+unit);


                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });

        requestQueue.add(objectRequest);

    }

    private void createDatabaseIfNotExists() {
        SQLiteDatabase db = null;
        try {
            db = openOrCreateDatabase("Database", MODE_PRIVATE, null);
            db.execSQL(CREATE_DRAWERS_TABLE);
            db.execSQL(CREATE_WEARS_TABLE);
            if(!restorePreData()) {
                db.execSQL(INSERT_DRAWERS_TABLE);
                db.execSQL(INSERT_WEARS_TABLE);
                db.execSQL(INSERT_WEARS_TABLE2);
                db.execSQL(INSERT_WEARS_TABLE3);
                db.execSQL(INSERT_WEARS_TABLE4);
                db.execSQL(INSERT_WEARS_TABLE5);
                db.execSQL(INSERT_WEARS_TABLE6);
                db.execSQL(INSERT_WEARS_TABLE7);
                db.execSQL(INSERT_WEARS_TABLE8);
                db.execSQL(INSERT_WEARS_TABLE9);
                db.execSQL(INSERT_WEARS_TABLE10);
                db.execSQL(INSERT_WEARS_TABLE11);
                db.execSQL(INSERT_WEARS_TABLE12);
                savePrefsData();
            }
            db.execSQL(CREATE_OUTFITS_TABLE);
            db.execSQL(CREATE_EVENTS_TABLE);
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), "An error occurred!", Toast.LENGTH_SHORT).show();
        } finally {
            if (db != null) db.close();
        }

        fetch();

    }

    private boolean restorePreData(){
        SharedPreferences preferences =  PreferenceManager.getDefaultSharedPreferences(this);
        return preferences.getBoolean("isMainOpened", false);
    }

    private void savePrefsData(){
        SharedPreferences preferences =  PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putBoolean("isMainOpened", true);
        editor.apply();
    }

    private void fetch(){
        String URL = "https://aularental.com/being/api_fact.php";
        Log.d("TAG", "URL: "+ URL);
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        JsonObjectRequest objectRequest = new JsonObjectRequest(Request.Method.GET, URL, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                Log.d("TAG", "onResponse: "+ response);

                try {
                    String fact_text = response.getString("fact");
                    TextView fact = findViewById(R.id.fact);
                    fact.setText(fact_text);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });

        requestQueue.add(objectRequest);
    }
}