package com.example.beingahuman.activities;

import android.app.Activity;
import android.app.DatePickerDialog.OnDateSetListener;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts.GetContent;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.WindowInsetsControllerCompat;

import com.example.beingahuman.R;

import static android.R.layout.simple_spinner_item;
import static android.widget.Toast.LENGTH_SHORT;
import static com.example.beingahuman.Utils.WearTypes.WEAR_TYPES;
import static com.example.beingahuman.Utils.convertBitmapToBytes;
import static com.example.beingahuman.Utils.getBitmapFromUri;
import static com.example.beingahuman.Utils.isDateStringValid;
import static com.example.beingahuman.Utils.pickDate;

public class CreateWearActivity extends AppCompatActivity {
    private ImageView wearImageView;
    private EditText wearNameEditText;
    private String colorText;
    private EditText patternEditText;
    private EditText priceEditText;
    private EditText datePurchasedEditText;
    private Spinner wearTypeSpinner;
    private Button selectWearImageButton;
    private Button saveWearButton;
    private ActivityResultLauncher<String> launcher;
    private Bitmap imageBitmap;

    int LAUNCH_SECOND_ACTIVITY = 111;

    Uri image_uri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initialize();
    }

    private void initialize() {

//        Palette.from(resource).generate(new Palette.PaletteAsyncListener() {
//            @Override
//            public void onGenerated(Palette palette) {
//                Palette.Swatch textSwatch = palette.getDominantSwatch();
//                if (textSwatch == null) {
//                    return;
//                }
//                int[] colors = {Color.TRANSPARENT, textSwatch.getRgb()};
//                GradientDrawable gd = new GradientDrawable(
//                        GradientDrawable.Orientation.TOP_BOTTOM, colors);
//                gd.setCornerRadius(0f);
//                holder.details_bg.setBackground(gd);
//
//            }
//        });

        setContentView(R.layout.activity_create_wear);

        Window window = this.getWindow();
        View vieww = window.getDecorView();

        new WindowInsetsControllerCompat(window,vieww).setAppearanceLightStatusBars(true);

        imageBitmap = null;
        wearImageView = findViewById(R.id.wearImageView);
        wearNameEditText = findViewById(R.id.wearNameEditText);
        colorText = null;
        wearTypeSpinner = findViewById(R.id.wearTypeSpinner);
        wearTypeSpinner.setAdapter(new ArrayAdapter<>(this, simple_spinner_item, WEAR_TYPES));
        selectWearImageButton = findViewById(R.id.selectWearImageButton);
        saveWearButton = findViewById(R.id.saveWearButton);
        launcher = registerForActivityResult(new GetContent(), uri -> assignImage(uri));
//        selectWearImageButton.setOnClickListener(_v -> launcher.launch(MIME_TYPE_IMAGE));

        selectWearImageButton.setOnClickListener(_v -> { final Intent intentColorPickerActivity = new Intent(this, ColorPickerActivity.class);
            startActivityForResult(intentColorPickerActivity, LAUNCH_SECOND_ACTIVITY);
        });


        saveWearButton.setOnClickListener(_v -> saveWear());

        ImageView back_button = findViewById(R.id.back_button);

        back_button.setOnClickListener(view -> {
            onBackPressed();
        });
    }

    private void saveWear() {
        String name = wearNameEditText.getText().toString();
        String color = colorText;
        String pattern = "pattern";
        int type = wearTypeSpinner.getSelectedItemPosition();
        float price = Float.parseFloat("99");
        String datePurchased = "2022-2-2";
        String image_url = image_uri.toString();
        int drawerId = getIntent().getIntExtra("id", -1);

        String errorMessage = getErrorMessage(name, color, pattern, type, price, datePurchased, imageBitmap, drawerId);
        if (errorMessage != null) {
            Toast.makeText(getApplicationContext(), errorMessage, LENGTH_SHORT).show();
            return;
        }

        SQLiteDatabase db = null;
        String message = null;
        try {
            db = openOrCreateDatabase("Database", MODE_PRIVATE, null);
            String sql = "INSERT INTO wears (name, color, pattern, type, price, date_purchased, photo, drawer_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            SQLiteStatement statement = db.compileStatement(sql);
            statement.bindString(1, name);
            statement.bindString(2, color);
            statement.bindString(3, pattern);
            statement.bindLong(4, type);
            statement.bindDouble(5, price);
            statement.bindString(6, datePurchased);
            statement.bindString(7, image_url);
            statement.bindLong(8, drawerId);
            statement.executeInsert();
            message = "Outfit successfully added!";
        } catch (Exception e) {
            e.printStackTrace();
            message = "Something went wrong!";
        } finally {
            if (db != null) db.close();
            Toast.makeText(getApplicationContext(), message, LENGTH_SHORT).show();
            finish();
        }
    }

    private String getErrorMessage(String name, String color, String pattern, int type, float price, String datePurchased, Bitmap imageBitmap, int drawerId) {
        if (name == null || name.length() <= 0) return "Please enter an outfit name!";
        if (color == null || color.length() <= 0) return "Please enter a color!";
        if (pattern == null || pattern.length() <= 0) return "Please enter a pattern!";
        if (type < 0 || type > 6) return "Please select an outfit type!";
        if (price < 0) return "Please enter a price!";
        if (!isDateStringValid(datePurchased)) return "Please enter a valid date!";
        if (imageBitmap == null) return "Please select a picture!";
        if (drawerId < 0) return "Something went wrong";
        return null;
    }

    private void assignImage(Uri uri) {
        Log.d("tag",uri.toString());
        Bitmap bitmap = getBitmapFromUri(uri, this);
        imageBitmap = bitmap;
        wearImageView.setImageBitmap(bitmap);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == LAUNCH_SECOND_ACTIVITY) {
            if(resultCode == Activity.RESULT_OK){
                String result=data.getStringExtra("result");
                image_uri = Uri.parse(Uri.decode(result));
                Bitmap bitmap = getBitmapFromUri(image_uri, this);
                imageBitmap = bitmap;
                wearImageView.setImageBitmap(bitmap);
                colorText = data.getStringExtra("color");
            }
            if (resultCode == Activity.RESULT_CANCELED) {
                // Write your code if there's no result
            }
        }
    } //onActivityResult
}