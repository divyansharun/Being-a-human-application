package com.example.beingahuman.fragments;


import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.core.content.ContextCompat;
import androidx.core.view.MenuItemCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.beingahuman.R;
import com.example.beingahuman.activities.ContactPickerActivity;
import com.example.beingahuman.activities.LovedOnesEditActivity;
import com.example.beingahuman.activities.LovedOnesDetailActivity;
import com.example.beingahuman.classes.Contact;
import com.example.beingahuman.classes.ContactLab;
import com.example.beingahuman.utils.PictureUtils;

import java.io.File;
import java.util.List;

import static android.content.ContentValues.TAG;

public class ContactListFragment extends Fragment {

    private RecyclerView mContactRecyclerView;
    private TextView mContactTextView;
    private ContactAdapter mAdapter;
    private String mQuery;
    private static final String SAVED_SUBTITLE_VISIBLE = "subtitle";

    private static final String CONTACT_ID = "contactID";

    public static String[] permissions = new String[]{
            Manifest.permission.WRITE_EXTERNAL_STORAGE,

    };

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_contact_list, container, false);
        mContactRecyclerView = (RecyclerView) view
                .findViewById(R.id.contact_recycler_view);
        mContactRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        mContactTextView = (TextView) view
                .findViewById(R.id.empty_view);

        updateUI();
        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        updateUI();
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.fragment_contact_list, menu);

        MenuItem searchItem = menu.findItem(R.id.menu_item_search);
        final SearchView searchView = (SearchView) MenuItemCompat.getActionView(searchItem);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                mQuery=s;
                updateUI();
                return true;
            }
            @Override
            public boolean onQueryTextChange(String s) {
                return false;
            }
        });

        searchView.setOnSearchClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                searchView.setQuery(mQuery, false);
            }
        });

        MenuItemCompat.setOnActionExpandListener(searchItem, new MenuItemCompat.OnActionExpandListener()
        {
            @Override
            public boolean onMenuItemActionCollapse(MenuItem item)
            {
                mQuery=null;
                updateUI();
                return true; // Return true to collapse action view
            }

            @Override
            public boolean onMenuItemActionExpand(MenuItem item)
            {
                return true;
            }
        });


    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_item_new_contact:
                Contact contact = new Contact();
                Intent intent = new Intent(getActivity(), ContactPickerActivity.class);
                startActivityForResult(intent,ContactEditFragment.ADD_CONTACT);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void updateSubtitle() {
        ContactLab contactLab = ContactLab.get(getActivity());

        int contactSize = contactLab.getContacts().size();
        String subtitle = getResources()
                .getQuantityString(R.plurals.subtitle_plural, contactSize, contactSize);


        AppCompatActivity activity = (AppCompatActivity) getActivity();
        activity.getSupportActionBar().setTitle("Loved Ones");
        activity.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    private void updateUI() {
        ContactLab contactLab = ContactLab.get(getActivity());
        List<Contact> contacts;
        if(mQuery==null)
            contacts = contactLab.getContacts();
        else
            contacts = contactLab.searchContactsByName(mQuery);

        if (mAdapter == null) {
            mAdapter = new ContactAdapter(contacts);
            mContactRecyclerView.setAdapter(mAdapter);
        } else {
            mAdapter.setContacts(contacts);
            mAdapter.notifyDataSetChanged();
            //mAdapter.notifyItemChanged(mAdapter.getPosition());
        }

        int contactSize = contactLab.getContacts().size();

        if (contactSize==0) {
            mContactRecyclerView.setVisibility(View.GONE);
            mContactTextView.setVisibility(View.VISIBLE);
        }
        else {
            mContactRecyclerView.setVisibility(View.VISIBLE);
            mContactTextView.setVisibility(View.GONE);
        }

        updateSubtitle();
    }

    private class ContactHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        private TextView mNameTextView;
        private ImageView mPhotoView;
        private CheckBox mSolvedCheckBox;
        private Contact mContact;
        private ContactAdapter mAdapter;
        int imageViewWidth=0;
        int imageViewHeight=0;



        public ContactHolder(View itemView, ContactAdapter adaptor ) {
            super(itemView);
            mNameTextView = (TextView)
                    itemView.findViewById(R.id.list_item_contact_name);
            mPhotoView = (ImageView)
                    itemView.findViewById(R.id.list_item_contact_photo);
            final ViewTreeObserver vto = mPhotoView.getViewTreeObserver();
            vto.addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
                @Override
                public void onGlobalLayout() {

                    imageViewWidth = mPhotoView.getWidth();
                    imageViewHeight = mPhotoView.getHeight();

                    updatePhotoView();

                    //Then remove layoutChange Listener
                    ViewTreeObserver vto = mPhotoView.getViewTreeObserver();
                    vto.removeOnGlobalLayoutListener(this);
                }
            });

            itemView.setOnClickListener(this);
            mAdapter=adaptor;
        }

        public void bindContact(Contact contact) {
            mContact = contact;
            mNameTextView.setText(mContact.getName());
            updatePhotoView();

        }
        private void updatePhotoView()
        {
            if(imageViewWidth!=0 && imageViewHeight!=0) {
                File mPhotoFile = ContactLab.get(getActivity()).getPhotoFile(mContact);
                if (mPhotoFile == null || !mPhotoFile.exists()) {
                    String name = mContact.getName();
                    if (name != null && !name.isEmpty()) {
                        String initials = String.valueOf(name.charAt(0));
                        //String char2 = String.valueOf(name.substring(name.indexOf(' ') + 1).charAt(0));
                        //if(char2!=null && !char2.isEmpty())
                        // initials = initials + char2;
                        Bitmap bitmap = PictureUtils.generateCircleBitmap(getContext(),
                                PictureUtils.getMaterialColor(name),
                                40, initials);
                        // + String.valueOf())
                        mPhotoView.setImageBitmap(bitmap);
                    } else
                        mPhotoView.setImageDrawable(null);

                } else {
                    mPhotoView.setImageBitmap(PictureUtils.getCircularBitmap(mPhotoFile.getPath(), 40,imageViewWidth, imageViewHeight));
                }
            }

        }

        @Override
        public void onClick(View v) {

            mAdapter.setPosition(getAdapterPosition());
            Intent intent = LovedOnesDetailActivity.newIntent(getActivity(), mContact.getId());
            startActivity(intent);
        }
    }

    private class ContactAdapter extends RecyclerView.Adapter<ContactHolder> {

        private List<Contact> mContacts;

        private int position;

        public ContactAdapter(List<Contact> contacts) {
            mContacts = contacts;
        }

        @Override
        public ContactHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(getActivity());
            View view = layoutInflater
                    .inflate(R.layout.list_item_contact, parent, false);
            return new ContactHolder(view,this);
        }

        @Override
        public void onBindViewHolder(ContactHolder holder, int position) {
            Contact contact = mContacts.get(position);
            holder.bindContact(contact);
        }

        @Override
        public int getItemCount() {
            return mContacts.size();
        }

        public void setContacts(List<Contact> contacts) {
            mContacts = contacts;
        }

        public int getPosition() {
            return position;
        }

        public void setPosition(int position) {
            this.position = position;
        }

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode != Activity.RESULT_OK) {
            return;
        }
        if (requestCode == ContactEditFragment.ADD_CONTACT) {

            String returnValue = data.getStringExtra(ContactEditFragment.RETURN_STATE);
            if(returnValue!=null) {
                if (returnValue.equals("0")){
                    Toast.makeText(getActivity(), "deleted",
                            Toast.LENGTH_SHORT).show();
                }
                else if (returnValue.equals("1")) {

                    Contact contact = (Contact) data.getSerializableExtra(ContactEditFragment.CONTACT_OBJECT);
                    if(contact!=null) {
                        Toast.makeText(getActivity(), "saved",
                                Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }

        updateUI();
    }


    public static boolean checkPermissions(Context context) {
        int result;

        for (String p:permissions) {
            result = ContextCompat.checkSelfPermission(context,p);
            if (result != PackageManager.PERMISSION_GRANTED) {
                return false;
            }
        }
        return true;
    }


    public void askPermissions() {
        int result;
        Toast.makeText(getActivity(), "Please grant permissions on next screen", Toast.LENGTH_SHORT).show();
        try {
            Thread.sleep(1000);} catch (Exception e) {
            Log.e(TAG, e.getMessage());}

        for (String p:permissions) {
            result = ContextCompat.checkSelfPermission(getActivity(),p);
            if (result != PackageManager.PERMISSION_GRANTED) {
               requestPermissions(new String[]{p}, 0);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case 0: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    // permission was granted, yay! continue

                } else {

                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                    Toast.makeText(getActivity(), "Permissions Not Granted", Toast.LENGTH_SHORT).show();
                    try {
                        Thread.sleep(1000);} catch (Exception e) {
                        Log.e(TAG, e.getMessage());}
                    //callback.finishActivity();
                }
                return;
            }

            // other 'case' lines to check for other
            // permissions this app might request
        }
    }


}
