package com.example.beingahuman.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;

import com.bumptech.glide.Glide;
import com.example.beingahuman.R;
import com.example.beingahuman.activities.EditWearActivity;
import com.example.beingahuman.models.Wear;

import java.util.ArrayList;

import static com.example.beingahuman.Utils.WearTypes.WEAR_TYPES;

public class WearHomeRecyclerAdapter extends RecyclerView.Adapter<WearHomeRecyclerAdapter.WearViewHolder> {
    private final ArrayList<Wear> wears;
    private final Context context;

    public WearHomeRecyclerAdapter(ArrayList<Wear> wears, Context context) {
        this.wears = wears;
        this.context = context;
    }

    @NonNull
    @Override
    public WearViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.single_item_wear_home, parent, false);
        return new WearHomeRecyclerAdapter.WearViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull WearViewHolder holder, int position) {
        Wear wear = wears.get(position);
        Glide.with(context).load(wear.getPhoto()).into(holder.wearItemImageView);
        holder.wearItemNameTextView.setText(wear.getName());
        holder.wearItemTypeTextView.setText(WEAR_TYPES[wear.getType()]);
        holder.wearItemColorPatternTextView.setText(wear.getColor());
        holder.wearItemPriceTextView.setText(Float.toString(wear.getPrice()));
        holder.wearItemPurchaseDateTextView.setText(wear.getDatePurchased());
        holder.itemCardView.setOnClickListener(_v -> goToEditWear(wear.getId()));
    }

    private void goToEditWear(int id) {
        Intent intent = new Intent(context, EditWearActivity.class);
        intent.putExtra("id", id);
        context.startActivity(intent);
    }

    @Override
    public int getItemCount() { return wears.size(); }

    public class WearViewHolder extends ViewHolder {
        private CardView itemCardView;
        private ImageView wearItemImageView;
        private ImageView wearItemRemoveIcon;
        private TextView wearItemNameTextView;
        private TextView wearItemTypeTextView;
        private TextView wearItemColorPatternTextView;
        private TextView wearItemPriceTextView;
        private TextView wearItemPurchaseDateTextView;

        public WearViewHolder(@NonNull View itemView) {
            super(itemView);
            itemCardView = itemView.findViewById(R.id.itemCardView);
            wearItemImageView = itemView.findViewById(R.id.wearItemImageView);
            wearItemRemoveIcon = itemView.findViewById(R.id.wearItemRemoveIcon);
            wearItemNameTextView = itemView.findViewById(R.id.wearItemNameTextView);
            wearItemTypeTextView = itemView.findViewById(R.id.wearItemTypeTextView);
            wearItemColorPatternTextView = itemView.findViewById(R.id.wearItemColorPatternTextView);
            wearItemPriceTextView = itemView.findViewById(R.id.wearItemPriceTextView);
            wearItemPurchaseDateTextView = itemView.findViewById(R.id.wearItemPurchaseDateTextView);
        }
    }
}
