package com.example.beingahuman.adapters;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;

import com.bumptech.glide.Glide;
import com.example.beingahuman.R;
import com.example.beingahuman.activities.EditWearActivity;
import com.example.beingahuman.activities.IngredientsActivity;
import com.example.beingahuman.models.Ingredient;

import java.util.ArrayList;

import static android.content.Context.MODE_PRIVATE;
import static android.widget.Toast.LENGTH_SHORT;
import static com.example.beingahuman.Utils.IngredientTypes.INGREDIENT_TYPES;

public class IngredientRecyclerAdapter extends RecyclerView.Adapter<IngredientRecyclerAdapter.WearViewHolder> {
    private final ArrayList<Ingredient> ingredients;
    private final Context context;

    public IngredientRecyclerAdapter(ArrayList<Ingredient> ingredients, Context context) {
        this.ingredients = ingredients;
        this.context = context;
    }

    @NonNull
    @Override
    public WearViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.single_item_ingredient, parent, false);
        return new IngredientRecyclerAdapter.WearViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull WearViewHolder holder, int position) {
        Ingredient ingredient = ingredients.get(position);
        Glide.with(context).load(ingredient.getPhoto()).into(holder.wearItemImageView);
//        holder.wearItemImageView.setImageBitmap(ingredient.getPhoto());
        holder.wearItemNameTextView.setText(ingredient.getName());
        holder.wearItemTypeTextView.setText(INGREDIENT_TYPES[ingredient.getType()]);
        holder.wearItemRemoveIcon.setOnClickListener(_v -> showRemoveWearDialog(ingredient.getId()));
    }

    private void goToEditWear(int id) {
        Intent intent = new Intent(context, EditWearActivity.class);
        intent.putExtra("id", id);
        context.startActivity(intent);
    }

    private void removeIngredient(int id) {
        SQLiteDatabase db = null;
        String message = null;
        try {
            db = context.openOrCreateDatabase("Database", MODE_PRIVATE, null);
            db.execSQL("DELETE FROM fridge WHERE id = " + id);
            message = "The items has been successfully deleted!";
        } catch (Exception e) {
            message = "Something went wrong!";
        } finally {
            if (db != null) db.close();
            Toast.makeText(context, message, LENGTH_SHORT).show();
            ((IngredientsActivity) context).fetchWears();
        }
    }

    private void showRemoveWearDialog(int id) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Delete Item?");
        builder.setMessage("Are you sure you want to delete this outfit?");
        builder.setPositiveButton("I'm sure, delete", (_d, _w) -> removeIngredient(id));
        builder.setNegativeButton("No, don't delete", (dialog, _w) -> dialog.cancel());
        builder.show();
    }

    @Override
    public int getItemCount() { return ingredients.size(); }

    public class WearViewHolder extends ViewHolder {
        private CardView itemCardView;
        private ImageView wearItemImageView;
        private ImageView wearItemRemoveIcon;
        private TextView wearItemNameTextView;
        private TextView wearItemTypeTextView;
        private TextView wearItemColorPatternTextView;
        private TextView wearItemPriceTextView;
        private TextView wearItemPurchaseDateTextView;

        public WearViewHolder(@NonNull View itemView) {
            super(itemView);
            itemCardView = itemView.findViewById(R.id.itemCardView);
            wearItemImageView = itemView.findViewById(R.id.wearItemImageView);
            wearItemRemoveIcon = itemView.findViewById(R.id.wearItemRemoveIcon);
            wearItemNameTextView = itemView.findViewById(R.id.wearItemNameTextView);
            wearItemTypeTextView = itemView.findViewById(R.id.wearItemTypeTextView);
            wearItemColorPatternTextView = itemView.findViewById(R.id.wearItemColorPatternTextView);
            wearItemPriceTextView = itemView.findViewById(R.id.wearItemPriceTextView);
            wearItemPurchaseDateTextView = itemView.findViewById(R.id.wearItemPurchaseDateTextView);
        }
    }
}
