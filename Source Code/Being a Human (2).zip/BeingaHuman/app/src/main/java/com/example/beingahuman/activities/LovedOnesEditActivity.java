package com.example.beingahuman.activities;

import android.content.Context;
import android.content.Intent;

import androidx.fragment.app.Fragment;

import com.example.beingahuman.classes.Contact;
import com.example.beingahuman.fragments.ContactEditFragment;


public class LovedOnesEditActivity extends SingleFragmentActivity {

    private static final String EXTRA_CONTACT =
            "com.allonsy.android.contacts.contact";

    private static final String EXTRA_REQUEST_TYPE =
            "com.allonsy.android.contacts.request_type";

    public static Intent newIntent(Context packageContext, Contact contact, int requestType) {
        Intent intent = new Intent(packageContext, LovedOnesEditActivity.class);
        intent.putExtra(EXTRA_CONTACT, contact);
        intent.putExtra(EXTRA_REQUEST_TYPE, requestType);
        return intent;
    }

    @Override
    protected Fragment createFragment() {
        Contact contact = (Contact) getIntent()
                .getSerializableExtra(EXTRA_CONTACT);
        int requestType = (int) getIntent()
                .getSerializableExtra(EXTRA_REQUEST_TYPE);
        return ContactEditFragment.newInstance(contact, requestType);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}
