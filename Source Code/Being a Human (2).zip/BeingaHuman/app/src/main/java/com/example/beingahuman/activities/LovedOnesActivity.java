package com.example.beingahuman.activities;


import androidx.fragment.app.Fragment;

import com.example.beingahuman.fragments.ContactListFragment;

public class LovedOnesActivity extends SingleFragmentActivity {
    @Override
    protected Fragment createFragment() {
        return new ContactListFragment();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}