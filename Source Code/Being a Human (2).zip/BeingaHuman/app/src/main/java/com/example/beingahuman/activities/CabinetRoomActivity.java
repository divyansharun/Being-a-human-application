package com.example.beingahuman.activities;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.beingahuman.adapters.OutfitRecyclerAdapter;
import com.example.beingahuman.models.Outfit;
import com.example.beingahuman.R;

import java.util.ArrayList;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;
import static android.widget.Toast.LENGTH_SHORT;

public class CabinetRoomActivity extends AppCompatActivity {
    private RecyclerView outfitsRecycler;
    private TextView noItemText;
    private ArrayList<Outfit> outfits;
    ImageView add_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initialize();
    }

    private void initialize() {
        setContentView(R.layout.activity_cabinet_room);

        Window window = this.getWindow();
        View vieww = window.getDecorView();

        new WindowInsetsControllerCompat(window,vieww).setAppearanceLightStatusBars(true);

        outfitsRecycler = findViewById(R.id.outfitsRecyclerView);
        noItemText = findViewById(R.id.noItemText);
        add_button = findViewById(R.id.add_button);

        ImageView back_button = findViewById(R.id.back_button);

        back_button.setOnClickListener(view -> onBackPressed());

        add_button.setOnClickListener(view -> {
            Intent intent = new Intent(this, CreateOutfitActivity.class);
            intent.putExtra("id", getIntent().getIntExtra("id", -1));
            startActivity(intent);
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        fetchOutfits();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_add, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        startActivity(new Intent(this, CreateOutfitActivity.class));
        return true;
    }

    public void fetchOutfits() {
        outfits = new ArrayList<>();
        SQLiteDatabase db = null;
        Cursor cursor = null;
        try {
            db = openOrCreateDatabase("Database", MODE_PRIVATE, null);
            cursor = db.rawQuery("SELECT * FROM outfits", null);
            while (cursor.moveToNext()) {
                String name = cursor.getString(cursor.getColumnIndex("name"));
                int id = cursor.getInt(cursor.getColumnIndex("id"));
                int hatId = cursor.getInt(cursor.getColumnIndex("hat"));
                int faceId = cursor.getInt(cursor.getColumnIndex("face_accessory"));
                int topId = cursor.getInt(cursor.getColumnIndex("top"));
                int jacketId = cursor.getInt(cursor.getColumnIndex("jacket"));
                int handArmId = cursor.getInt(cursor.getColumnIndex("hand_arm_accessory"));
                int bottomsId = cursor.getInt(cursor.getColumnIndex("bottoms"));
                int shoesId = cursor.getInt(cursor.getColumnIndex("shoes"));
                Outfit outfit = new Outfit(id, name, hatId, faceId, topId, jacketId, handArmId, bottomsId, shoesId);
                outfits.add(outfit);
            }
        } catch (Exception e) {
            Toast.makeText(this, "Something went wrong!", LENGTH_SHORT);
        } finally {
            if (cursor != null) cursor.close();
            if (db != null) db.close();
            OutfitRecyclerAdapter adapter = new OutfitRecyclerAdapter(outfits, this);
            outfitsRecycler.setAdapter(adapter);
            outfitsRecycler.setLayoutManager(new LinearLayoutManager(this));
            adapter.notifyDataSetChanged();
            noItemText.setVisibility(outfits.size() == 0 ? VISIBLE : GONE);
        }
    }
}