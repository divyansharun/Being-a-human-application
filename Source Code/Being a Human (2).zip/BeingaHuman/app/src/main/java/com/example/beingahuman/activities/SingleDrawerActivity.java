package com.example.beingahuman.activities;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.beingahuman.adapters.WearRecyclerAdapter;
import com.example.beingahuman.models.Wear;
import com.example.beingahuman.R;

import java.util.ArrayList;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;
import static android.widget.Toast.LENGTH_SHORT;
import static com.example.beingahuman.Utils.convertBytesToBitmap;
import static com.example.beingahuman.Utils.getBitmapFromUri;

public class SingleDrawerActivity extends AppCompatActivity {
    private RecyclerView wearsRecycler;
    private TextView noItemText;
    private ArrayList<Wear> wears;
    private int drawerId;
    ImageView add_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initialize();
    }

    private void initialize() {
        setContentView(R.layout.activity_single_drawer);

        Window window = this.getWindow();
        View vieww = window.getDecorView();

        new WindowInsetsControllerCompat(window,vieww).setAppearanceLightStatusBars(true);

        drawerId = getIntent().getIntExtra("id", -1);
        wearsRecycler = findViewById(R.id.wearsRecyclerView);
        noItemText = findViewById(R.id.noItemText);
        add_button = findViewById(R.id.add_button);

        add_button.setOnClickListener(view -> {
            Intent intent = new Intent(this, CreateWearActivity.class);
            intent.putExtra("id", getIntent().getIntExtra("id", -1));
            startActivity(intent);
        });

        ImageView back_button = findViewById(R.id.back_button);

        back_button.setOnClickListener(view -> {
            onBackPressed();
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        fetchWears();
    }

//    @Override
//    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
//        Intent intent = new Intent(this, CreateWearActivity.class);
//        intent.putExtra("id", getIntent().getIntExtra("id", -1));
//        startActivity(intent);
//        return true;
//    }

    public void fetchWears() {
        wears = new ArrayList<>();
        SQLiteDatabase db = null;
        Cursor cursor = null;
        try {
            db = openOrCreateDatabase("Database", MODE_PRIVATE, null);
            cursor = db.rawQuery("SELECT * FROM wears WHERE drawer_id = " + drawerId, null);
            while (cursor.moveToNext()) {
                int id = cursor.getInt(cursor.getColumnIndex("id"));
                String name = cursor.getString(cursor.getColumnIndex("name"));
                String color = cursor.getString(cursor.getColumnIndex("color"));
                String pattern = cursor.getString(cursor.getColumnIndex("pattern"));
                int type = cursor.getInt(cursor.getColumnIndex("type"));
                float price = cursor.getFloat(cursor.getColumnIndex("price"));
                String datePurchased = cursor.getString(cursor.getColumnIndex("date_purchased"));
                String photo = cursor.getString(cursor.getColumnIndex("photo"));
                Wear wear = new Wear(id, name, color, pattern, type, price, datePurchased, photo);
                wears.add(wear);
            }
        } catch (Exception e) {
            Toast.makeText(this, "Something went wrong!", LENGTH_SHORT);
        } finally {
            if (cursor != null) cursor.close();
            if (db != null) db.close();
            WearRecyclerAdapter adapter = new WearRecyclerAdapter(wears, this);
            wearsRecycler.setAdapter(adapter);
            wearsRecycler.setLayoutManager(new LinearLayoutManager(this));
            adapter.notifyDataSetChanged();
            noItemText.setVisibility(wears.size() == 0 ? VISIBLE : GONE);
        }
    }
}