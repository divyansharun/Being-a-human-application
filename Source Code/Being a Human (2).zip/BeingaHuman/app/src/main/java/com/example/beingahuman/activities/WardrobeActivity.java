package com.example.beingahuman.activities;

import android.content.Intent;
import android.database.Cursor;
import android.database.CursorWindow;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.beingahuman.R;
import com.example.beingahuman.adapters.WearHomeRecyclerAdapter;
import com.example.beingahuman.models.Wear;

import java.lang.reflect.Field;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;
import static android.widget.Toast.LENGTH_SHORT;
import static com.example.beingahuman.Utils.SQLCodes.CREATE_DRAWERS_TABLE;
import static com.example.beingahuman.Utils.SQLCodes.CREATE_EVENTS_TABLE;
import static com.example.beingahuman.Utils.SQLCodes.CREATE_OUTFITS_TABLE;
import static com.example.beingahuman.Utils.SQLCodes.CREATE_WEARS_TABLE;
import static com.example.beingahuman.Utils.convertBytesToBitmap;
import static com.example.beingahuman.Utils.getBitmapFromUri;

public class WardrobeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            Field field = CursorWindow.class.getDeclaredField("sCursorWindowSize");
            field.setAccessible(true);
            field.set(null, 100 * 1024 * 1024); //the 100MB is the new size
        } catch (Exception e) {
            e.printStackTrace();
        }
        initialize();
    }

    private void initialize() {
        setContentView(R.layout.activity_wardrobe);

        Window window = this.getWindow();
        View vieww = window.getDecorView();

        new WindowInsetsControllerCompat(window,vieww).setAppearanceLightStatusBars(true);

        RelativeLayout goToDrawersButton = findViewById(R.id.goToDrawersButton);
        RelativeLayout goToCabinetRoomButton = findViewById(R.id.goToCabinetRoomButton);
        RelativeLayout goToTodaysComb = findViewById(R.id.goToTodaysCombButton);

//        RelativeLayout goToTodaysComb = findViewById(R.id.goToEventsButton);

        goToDrawersButton.setOnClickListener(v -> goToDrawers());
        goToCabinetRoomButton.setOnClickListener(v -> goToCabinetRoom());
        goToTodaysComb.setOnClickListener(v -> goToTodaysComb());

        createDatabaseIfNotExists();
    }

    private void createDatabaseIfNotExists() {
        SQLiteDatabase db = null;
        try {
            db = openOrCreateDatabase("Database", MODE_PRIVATE, null);
            db.execSQL(CREATE_DRAWERS_TABLE);
            db.execSQL(CREATE_WEARS_TABLE);
            db.execSQL(CREATE_OUTFITS_TABLE);
            db.execSQL(CREATE_EVENTS_TABLE);
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), "An error occurred!", Toast.LENGTH_SHORT).show();
        } finally {
            if (db != null) db.close();
        }
    }

    private void goToDrawers() {
        startActivity(new Intent(this, DrawersActivity.class));
    }

    private void goToCabinetRoom() {
        startActivity(new Intent(this, CabinetRoomActivity.class));
    }

    private void goToTodaysComb() {
        startActivity(new Intent(this, TodaysCombActivity.class));
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

}