package com.example.beingahuman.adapters;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityOptionsCompat;
import androidx.core.util.Pair;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;

import com.bumptech.glide.Glide;
import com.example.beingahuman.R;
import com.example.beingahuman.activities.EditWearActivity;
import com.example.beingahuman.activities.IngredientsActivity;
import com.example.beingahuman.activities.RecipeDetailsActivity;
import com.example.beingahuman.models.Dishes;
import com.example.beingahuman.models.Items;
import com.example.beingahuman.models.TempIngredient;

import java.util.ArrayList;

import static android.content.Context.MODE_PRIVATE;
import static android.widget.Toast.LENGTH_SHORT;
import static com.example.beingahuman.Utils.IngredientTypes.INGREDIENT_TYPES;

public class DishesRecyclerAdapter extends RecyclerView.Adapter<DishesRecyclerAdapter.WearViewHolder> {
    private final ArrayList<Dishes> dishes;
    private final Context context;

    public DishesRecyclerAdapter(ArrayList<Dishes> dishes, Context context) {
        this.dishes = dishes;
        this.context = context;
    }

    @NonNull
    @Override
    public WearViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.single_item_dish, parent, false);
        return new DishesRecyclerAdapter.WearViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull WearViewHolder holder, int position) {
        Dishes dish = dishes.get(position);
        Glide.with(context).load(dish.getPhoto()).into(holder.wearItemImageView);
//        holder.wearItemImageView.setImageBitmap(ingredient.getPhoto());
        holder.wearItemNameTextView.setText(dish.getName());
        if (dish.getType().equals("non-veg")){
            holder.type_icon.setImageResource(R.drawable.non_veg);
            holder.type.setText("Non-Veg");
        }
        holder.time.setText(dish.getTime());
        int[] colors = {Color.TRANSPARENT, Color.WHITE, Color.WHITE};
        GradientDrawable gd = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM, colors);
        gd.setCornerRadius(0f);
        holder.details_bg.setBackground(gd);

        holder.itemCardView.setOnClickListener(view -> {
            Intent intent = new Intent(context, RecipeDetailsActivity.class);
            intent.putExtra("title", dish.getName());
            intent.putExtra("calories", dish.getCalories());
            intent.putExtra("fats", dish.getFats());
            intent.putExtra("time", dish.getTime());
            intent.putExtra("ingredients", dish.getIngredients());
            intent.putExtra("preparation", dish.getPreparation());
            intent.putExtra("cooking", dish.getCooking());
            intent.putExtra("image", dish.getPhoto());
            Pair<View, String> p1 = Pair.create((View) holder.wearItemImageView, "image");
            ActivityOptionsCompat options = ActivityOptionsCompat.makeSceneTransitionAnimation((Activity) context, p1);
            context.startActivity(intent, options.toBundle());
        });


    }

    private void goToEditWear(int id) {
        Intent intent = new Intent(context, EditWearActivity.class);
        intent.putExtra("id", id);
        context.startActivity(intent);
    }

    private void addItemToFridge(int id, String name, int type, String image_url) {
        SQLiteDatabase db = null;
        String message = null;
        try {
            db = context.openOrCreateDatabase("Database", MODE_PRIVATE, null);
            String sql = "INSERT INTO fridge (i_id, name, type, photo) VALUES (?, ?, ?, ?)";
            SQLiteStatement statement = db.compileStatement(sql);
            statement.bindLong(1, id);
            statement.bindString(2, name);
            statement.bindLong(3, type);
            statement.bindString(4, image_url);
            statement.executeInsert();
            message = "Item successfully added!";
        } catch (Exception e) {
            e.printStackTrace();
            message = "Something went wrong!";
        } finally {
            if (db != null) db.close();
            Toast.makeText(context, message, LENGTH_SHORT).show();
        }
    }

    @Override
    public int getItemCount() { return dishes.size(); }

    public class WearViewHolder extends ViewHolder {
        private CardView itemCardView;
        private RelativeLayout details_bg;
        private ImageView wearItemImageView;
        private ImageView wearItemRemoveIcon;
        private ImageView added_icon;
        private ImageView type_icon;
        private TextView wearItemNameTextView;
        private TextView type;
        private TextView time;

        public WearViewHolder(@NonNull View itemView) {
            super(itemView);
            itemCardView = itemView.findViewById(R.id.itemCardView);
            details_bg = itemView.findViewById(R.id.details_bg);
            wearItemImageView = itemView.findViewById(R.id.wearItemImageView);
            wearItemRemoveIcon = itemView.findViewById(R.id.wearItemRemoveIcon);
            added_icon = itemView.findViewById(R.id.added_icon);
            wearItemNameTextView = itemView.findViewById(R.id.wearItemNameTextView);
            type = itemView.findViewById(R.id.type_text);
            type_icon = itemView.findViewById(R.id.type_icon);
            time = itemView.findViewById(R.id.time);
        }
    }
}
