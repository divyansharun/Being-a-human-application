package com.example.beingahuman.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.beingahuman.R;
import com.example.beingahuman.adapters.DishesRecyclerAdapter;
import com.example.beingahuman.adapters.ItemsRecyclerAdapter;
import com.example.beingahuman.models.Dishes;
import com.example.beingahuman.models.Items;
import com.example.beingahuman.models.TempIngredient;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import static android.widget.Toast.LENGTH_SHORT;

public class RecipeActivity extends AppCompatActivity {

    String items;
    ArrayList<Dishes> dishes;
    RecyclerView items_recycler;
    DishesRecyclerAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe);

        dishes = new ArrayList<>();

        items_recycler = findViewById(R.id.itemsRecyclerView);
        fetchIngredients();
        senddetaills();

        adapter = new DishesRecyclerAdapter(dishes, this);
        items_recycler.setAdapter(adapter);
        items_recycler.setLayoutManager(new LinearLayoutManager(getApplicationContext()));


        ImageView erase_button = findViewById(R.id.erase_button);
        EditText SearchEdit = findViewById(R.id.search_edit_text);
        SearchEdit.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                String strCHR = SearchEdit.getText().toString();
                if (SearchEdit.getText().toString().length() > 0) {
                    erase_button.setVisibility(View.VISIBLE);
                    ArrayList<Dishes> listNew = new ArrayList<>();
                    for (int l = 0; l < dishes.size(); l++) {
                        String serviceName = dishes.get(l).getName().toLowerCase();
                        if (serviceName.contains(strCHR.toLowerCase())) {
                            listNew.add(dishes.get(l));
                        }
                    }
                    items_recycler.setVisibility(View.VISIBLE);
                    adapter = new DishesRecyclerAdapter(listNew, RecipeActivity.this);
                } else {
                    erase_button.setVisibility(View.GONE);
                    items_recycler.setVisibility(View.VISIBLE);
                    adapter = new DishesRecyclerAdapter(dishes, RecipeActivity.this);
                }
                items_recycler.setAdapter(adapter);
            }
        });

        erase_button.setOnClickListener(view -> {
            SearchEdit.setText("");
        });


    }

    public void senddetaills(){

        String URL = "https://aularental.com/being/api_recipe.php?items="+items;
        Log.d("TAG", "URL: "+ URL);
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        JsonObjectRequest objectRequest = new JsonObjectRequest(Request.Method.GET, URL, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                Log.d("TAG", "onResponse: " + response);


                try {
                    JSONArray ings = response.getJSONArray("dishes");

                    for (int i = 0; i< ings.length();i++) {
                        JSONObject itm = ings.getJSONObject(i);
                        int id = itm.getInt("dish_id");
                        String name = itm.getString("name");
                        Log.d("TAG", "onResponse: " + name);
                        String photo_url = itm.getString("photo");
                        String ingredients = itm.getString("ingredients");
                        String preparation = itm.getString("preparation");
                        String cooking = itm.getString("cooking");
                        String type = itm.getString("veg/non-veg");
                        String time = itm.getString("time");
                        String calories = itm.getString("calories");
                        String fats = itm.getString("fats");

                        Dishes dish = new Dishes(id, name, time, type, photo_url, ingredients, preparation, cooking, calories, fats);
                        dishes.add(dish);

                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }


                adapter.notifyDataSetChanged();

            }

        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });

        requestQueue.add(objectRequest);

    }

    public void fetchIngredients() {
        List<String> list = new ArrayList<>();

        SQLiteDatabase db = null;
        Cursor cursor = null;
        try {
            db = openOrCreateDatabase("Database", MODE_PRIVATE, null);
            cursor = db.rawQuery("SELECT * FROM fridge", null);

            while (cursor.moveToNext()) {
                int id = cursor.getInt(cursor.getColumnIndex("id"));
                int i_id = cursor.getInt(cursor.getColumnIndex("i_id"));
                String name = cursor.getString(cursor.getColumnIndex("name"));
                int type = cursor.getInt(cursor.getColumnIndex("type"));
                String photo = Uri.parse(Uri.decode(cursor.getString(cursor.getColumnIndex("photo")))).toString();
                list.add(Integer.toString(i_id));

            }
        } catch (Exception e) {
            Toast.makeText(this, "Something went wrong!", LENGTH_SHORT);
        } finally {
            items = TextUtils.join(", ", list);

            Log.d("LIST", items);
        }
    }
}