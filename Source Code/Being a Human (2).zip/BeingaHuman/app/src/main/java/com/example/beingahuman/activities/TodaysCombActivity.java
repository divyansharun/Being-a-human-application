package com.example.beingahuman.activities;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.beingahuman.adapters.WearHomeRecyclerAdapter;
import com.example.beingahuman.adapters.WearRecyclerAdapter;
import com.example.beingahuman.models.Wear;
import com.example.beingahuman.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;
import static android.widget.Toast.LENGTH_SHORT;
import static com.example.beingahuman.Utils.convertBytesToBitmap;

public class TodaysCombActivity extends AppCompatActivity {
    private RecyclerView wearsRecycler;
    private TextView noItemText;
    private ArrayList<Wear> wears;
    String todays_color_sql;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initialize();
    }

    private void initialize() {
        setContentView(R.layout.activity_todays_comb);

        Window window = this.getWindow();
        View vieww = window.getDecorView();

        new WindowInsetsControllerCompat(window,vieww).setAppearanceLightStatusBars(true);

        SimpleDateFormat sdf = new SimpleDateFormat("EEEE");
        Date d = new Date();
        String dayOfTheWeek = sdf.format(d);

        if(dayOfTheWeek.equals("Monday")){
            todays_color_sql = "color = 'white'";
        } else if(dayOfTheWeek.equals("Tuesday")){
            todays_color_sql = "color = 'red'";
        } else if(dayOfTheWeek.equals("Wednesday")){
            todays_color_sql = "color = 'green'";
        } else if(dayOfTheWeek.equals("Thursday")){
            todays_color_sql = "color = 'yellow'";
        } else if(dayOfTheWeek.equals("Friday")){
            todays_color_sql = "color = 'blue' OR color = 'white'";
        } else if(dayOfTheWeek.equals("Saturday")){
            todays_color_sql = "color = 'purple' OR color = 'black'";
        } else if(dayOfTheWeek.equals("Sunday")){
            todays_color_sql = "color = 'pink'";
        }

        wearsRecycler = findViewById(R.id.wearsRecyclerView);
        noItemText = findViewById(R.id.noItemText);

        noItemText.setText("It's " + dayOfTheWeek + ", you should wear something from recommended outfits.");
    }

    @Override
    protected void onStart() {
        super.onStart();
        fetchWears(0);
    }

//    @Override
//    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
//        Intent intent = new Intent(this, CreateWearActivity.class);
//        intent.putExtra("id", getIntent().getIntExtra("id", -1));
//        startActivity(intent);
//        return true;
//    }

    public void fetchWears(int is_random) {
        wears = new ArrayList<>();
        SQLiteDatabase db = null;
        Cursor cursor = null;
        db = openOrCreateDatabase("Database", MODE_PRIVATE, null);

        if(is_random == 1){
            noItemText.setText("You don't have any recommended color outfit for today so here are some random outfits.");
            cursor = db.rawQuery("SELECT * FROM wears ORDER BY RANDOM()", null);
        }else {
            cursor = db.rawQuery("SELECT * FROM wears WHERE " + todays_color_sql, null);
        }

        try {
            while (cursor.moveToNext()) {
                int id = cursor.getInt(cursor.getColumnIndex("id"));
                String name = cursor.getString(cursor.getColumnIndex("name"));
                String color = cursor.getString(cursor.getColumnIndex("color"));
                String pattern = cursor.getString(cursor.getColumnIndex("pattern"));
                int type = cursor.getInt(cursor.getColumnIndex("type"));
                float price = cursor.getFloat(cursor.getColumnIndex("price"));
                String datePurchased = cursor.getString(cursor.getColumnIndex("date_purchased"));
                String photo = cursor.getString(cursor.getColumnIndex("photo"));
                Wear wear = new Wear(id, name, color, pattern, type, price, datePurchased, photo);
                wears.add(wear);
            }
        } catch (Exception e) {
            Toast.makeText(this, "Something went wrong!", LENGTH_SHORT);
        } finally {
            if (cursor != null) cursor.close();
            if (db != null) db.close();
            if(wears.size() == 0){
                if(is_random != 1) {
                    fetchWears(1);
                }
            }
            WearRecyclerAdapter adapter = new WearRecyclerAdapter(wears, this);
            wearsRecycler.setAdapter(adapter);
            wearsRecycler.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
            adapter.notifyDataSetChanged();
        }
    }
}