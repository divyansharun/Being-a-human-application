package com.example.beingahuman.activities;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.beingahuman.R;
import com.example.beingahuman.adapters.ItemsRecyclerAdapter;
import com.example.beingahuman.models.Items;
import com.example.beingahuman.models.TempIngredient;
import com.google.android.material.chip.Chip;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import static android.widget.Toast.LENGTH_SHORT;
import static com.example.beingahuman.Utils.IngredientTypes.DAIRY_PRODUCTS;
import static com.example.beingahuman.Utils.IngredientTypes.FRUITS;
import static com.example.beingahuman.Utils.IngredientTypes.MUSHROOMS;
import static com.example.beingahuman.Utils.IngredientTypes.VEGETABLES;
import static com.example.beingahuman.Utils.getBitmapFromUri;

public class NewIngredientActivity extends AppCompatActivity {
    private ImageView wearImageView;
    private EditText wearNameEditText;
    private Spinner wearTypeSpinner;
    private Button selectWearImageButton;
    private Button saveWearButton;
    private ActivityResultLauncher<String> launcher;
    private Bitmap imageBitmap;

    int LAUNCH_SECOND_ACTIVITY = 111;
    RecyclerView items_recycler;
    ItemsRecyclerAdapter adapter;

    Uri image_uri;
    ArrayList<Items> items;
    ArrayList<TempIngredient> ingredients;
    Chip all_chip, veg_chip, dairy_chip, mush_chip, fruit_chip;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initialize();
    }

    private void initialize() {

//        Palette.from(resource).generate(new Palette.PaletteAsyncListener() {
//            @Override
//            public void onGenerated(Palette palette) {
//                Palette.Swatch textSwatch = palette.getDominantSwatch();
//                if (textSwatch == null) {
//                    return;
//                }
//                int[] colors = {Color.TRANSPARENT, textSwatch.getRgb()};
//                GradientDrawable gd = new GradientDrawable(
//                        GradientDrawable.Orientation.TOP_BOTTOM, colors);
//                gd.setCornerRadius(0f);
//                holder.details_bg.setBackground(gd);
//
//            }
//        });

        setContentView(R.layout.activity_new_ingredient);

        Window window = this.getWindow();
        View vieww = window.getDecorView();

        new WindowInsetsControllerCompat(window,vieww).setAppearanceLightStatusBars(true);

        imageBitmap = null;
//        wearImageView = findViewById(R.id.wearImageView);
//        wearNameEditText = findViewById(R.id.wearNameEditText);
//        wearTypeSpinner = findViewById(R.id.wearTypeSpinner);
//        wearTypeSpinner.setAdapter(new ArrayAdapter<>(this, simple_spinner_item, INGREDIENT_TYPES));
//        selectWearImageButton = findViewById(R.id.selectWearImageButton);
//        saveWearButton = findViewById(R.id.saveWearButton);
//        launcher = registerForActivityResult(new GetContent(), uri -> assignImage(uri));
//        selectWearImageButton.setOnClickListener(_v -> launcher.launch(MIME_TYPE_IMAGE));

//        selectWearImageButton.setOnClickListener(_v -> { final Intent intentColorPickerActivity = new Intent(this, ColorPickerActivity.class);
//            startActivityForResult(intentColorPickerActivity, LAUNCH_SECOND_ACTIVITY);
//        });


//        saveWearButton.setOnClickListener(_v -> saveWear());
        items_recycler = findViewById(R.id.itemsRecyclerView);

        ImageView back_button = findViewById(R.id.back_button);

        back_button.setOnClickListener(view -> {
            onBackPressed();
        });

//        ingredients = (ArrayList<Ingredient>) getIntent().getSerializableExtra("ingredients");
//
//        if (ingredients != null) {
//
//            Log.d("listis",""+ingredients.toString());
//        }

        items = new ArrayList<>();
        ingredients = new ArrayList<>();

        fetchIngredients();

        Log.d("listis",""+ingredients.toString());
        adapter = new ItemsRecyclerAdapter(items, ingredients, getApplicationContext());
        items_recycler.setAdapter(adapter);
        items_recycler.setLayoutManager(new GridLayoutManager(getApplicationContext(), 2));

        fetch_items();

        all_chip = findViewById(R.id.chip_all);
        veg_chip = findViewById(R.id.chip_veg);
        dairy_chip = findViewById(R.id.chip_dairy);
        fruit_chip = findViewById(R.id.chip_fruits);
        mush_chip = findViewById(R.id.chip_mush);

        ImageView erase_button = findViewById(R.id.erase_button);
        EditText SearchEdit = findViewById(R.id.search_edit_text);
        SearchEdit.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                all_chip.setChecked(true);
                String strCHR = SearchEdit.getText().toString();
                if (SearchEdit.getText().toString().length() > 0) {
                    erase_button.setVisibility(View.VISIBLE);
                    ArrayList<Items> listNew = new ArrayList<>();
                    for (int l = 0; l < items.size(); l++) {
                        String serviceName = items.get(l).getName().toLowerCase();
                        if (serviceName.contains(strCHR.toLowerCase())) {
                            listNew.add(items.get(l));
                        }
                    }
                    items_recycler.setVisibility(View.VISIBLE);
                    adapter = new ItemsRecyclerAdapter(listNew, ingredients, getApplicationContext());
                } else {
                    erase_button.setVisibility(View.GONE);
                    items_recycler.setVisibility(View.VISIBLE);
                    adapter = new ItemsRecyclerAdapter(items, ingredients, getApplicationContext());
                }
                items_recycler.setAdapter(adapter);
            }
        });

        erase_button.setOnClickListener(view -> {
            SearchEdit.setText("");
        });

        all_chip.setOnClickListener(view -> {
            items_recycler.setVisibility(View.VISIBLE);
            adapter = new ItemsRecyclerAdapter(items, ingredients, getApplicationContext());
            items_recycler.setAdapter(adapter);
        });
        veg_chip.setOnClickListener(view -> {
            ArrayList<Items> listNew = new ArrayList<>();
            for (int l = 0; l < items.size(); l++) {
                int typee = items.get(l).getType();
                if (typee == VEGETABLES) {
                    listNew.add(items.get(l));
                }
            }
            items_recycler.setVisibility(View.VISIBLE);
            adapter = new ItemsRecyclerAdapter(listNew, ingredients, getApplicationContext());
            items_recycler.setAdapter(adapter);
        });
        fruit_chip.setOnClickListener(view -> {
            ArrayList<Items> listNew = new ArrayList<>();
            for (int l = 0; l < items.size(); l++) {
                int typee = items.get(l).getType();
                if (typee == FRUITS) {
                    listNew.add(items.get(l));
                }
            }
            items_recycler.setVisibility(View.VISIBLE);
            adapter = new ItemsRecyclerAdapter(listNew, ingredients, getApplicationContext());
            items_recycler.setAdapter(adapter);
        });
        dairy_chip.setOnClickListener(view -> {
            ArrayList<Items> listNew = new ArrayList<>();
            for (int l = 0; l < items.size(); l++) {
                int typee = items.get(l).getType();
                if (typee == DAIRY_PRODUCTS) {
                    listNew.add(items.get(l));
                }
            }
            items_recycler.setVisibility(View.VISIBLE);
            adapter = new ItemsRecyclerAdapter(listNew, ingredients, getApplicationContext());
            items_recycler.setAdapter(adapter);
        });
        mush_chip.setOnClickListener(view -> {
            ArrayList<Items> listNew = new ArrayList<>();
            for (int l = 0; l < items.size(); l++) {
                int typee = items.get(l).getType();
                if (typee == MUSHROOMS) {
                    listNew.add(items.get(l));
                }
            }
            items_recycler.setVisibility(View.VISIBLE);
            adapter = new ItemsRecyclerAdapter(listNew, ingredients, getApplicationContext());
            items_recycler.setAdapter(adapter);
        });

    }

    private void saveWear() {
        String name = wearNameEditText.getText().toString();
        int type = wearTypeSpinner.getSelectedItemPosition();
        String image_url = image_uri.toString();

//        String errorMessage = getErrorMessage(name, type, imageBitmap);
//        if (errorMessage != null) {
//            Toast.makeText(getApplicationContext(), errorMessage, LENGTH_SHORT).show();
//            return;
//        }

        SQLiteDatabase db = null;
        String message = null;
        try {
            db = openOrCreateDatabase("Database", MODE_PRIVATE, null);
            String sql = "INSERT INTO fridge (name, type, photo) VALUES (?, ?, ?)";
            SQLiteStatement statement = db.compileStatement(sql);
            statement.bindString(1, name);
            statement.bindLong(2, type);
            statement.bindString(3, image_url);
            statement.executeInsert();
            message = "Item successfully added!";
        } catch (Exception e) {
            e.printStackTrace();
            message = "Something went wrong!";
        } finally {
            if (db != null) db.close();
            Toast.makeText(getApplicationContext(), message, LENGTH_SHORT).show();
            finish();
        }
    }

    private void assignImage(Uri uri) {
        Log.d("tag",uri.toString());
        Bitmap bitmap = getBitmapFromUri(uri, this);
        imageBitmap = bitmap;
        wearImageView.setImageBitmap(bitmap);
    }

    public void fetch_items(){
        String URL = "https://aularental.com/being/api.php";
        Log.d("TAG", "URL: "+ URL);
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        JsonObjectRequest objectRequest = new JsonObjectRequest(Request.Method.GET, URL, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                Log.d("TAG", "onResponse: " + response);


                try {
                    JSONArray ings = response.getJSONArray("items");

                    for (int i = 0; i< ings.length();i++) {
                        JSONObject itm = ings.getJSONObject(i);
                        int id = itm.getInt("i_id");
                        String name = itm.getString("name");
                        Log.d("TAG", "onResponse: " + name);
                        String photo_url = itm.getString("photo");
                        int type = itm.getInt("type");

                        Items item = new Items(id, name, type, photo_url);
                        items.add(item);



                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }


                adapter.notifyDataSetChanged();

            }

            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {

                }
            });

        requestQueue.add(objectRequest);
    }

    public void fetchIngredients() {
        SQLiteDatabase db = null;
        Cursor cursor = null;
        try {
            db = openOrCreateDatabase("Database", MODE_PRIVATE, null);
            cursor = db.rawQuery("SELECT * FROM fridge", null);

            while (cursor.moveToNext()) {
                int id = cursor.getInt(cursor.getColumnIndex("id"));
                int i_id = cursor.getInt(cursor.getColumnIndex("i_id"));
                String name = cursor.getString(cursor.getColumnIndex("name"));
                int type = cursor.getInt(cursor.getColumnIndex("type"));
                String photo = Uri.parse(Uri.decode(cursor.getString(cursor.getColumnIndex("photo")))).toString();
                TempIngredient ingredient = new TempIngredient(id, i_id, name, type, photo);
                ingredients.add(ingredient);
            }
        } catch (Exception e) {
            Toast.makeText(this, "Something went wrong!", LENGTH_SHORT);
        } finally {

        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == LAUNCH_SECOND_ACTIVITY) {
            if(resultCode == Activity.RESULT_OK){
                String result=data.getStringExtra("result");
                image_uri = Uri.parse(Uri.decode(result));
                Bitmap bitmap = getBitmapFromUri(image_uri, this);
                imageBitmap = bitmap;
                wearImageView.setImageBitmap(bitmap);
            }
            if (resultCode == Activity.RESULT_CANCELED) {
                // Write your code if there's no result
            }
        }
    } //onActivityResult
}