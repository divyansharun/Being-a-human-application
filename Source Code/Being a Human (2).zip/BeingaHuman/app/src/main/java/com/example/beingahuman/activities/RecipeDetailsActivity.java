package com.example.beingahuman.activities;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.example.beingahuman.R;
import com.example.beingahuman.adapters.DishesRecyclerAdapter;
import com.example.beingahuman.models.Dishes;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import static android.widget.Toast.LENGTH_SHORT;

public class RecipeDetailsActivity extends AppCompatActivity {

    String items;
    ArrayList<Dishes> dishes;
    RecyclerView items_recycler;
    DishesRecyclerAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe_details);

        String name = getIntent().getStringExtra("title");
        String time = getIntent().getStringExtra("time");
        String calories = getIntent().getStringExtra("calories");
        String fats = getIntent().getStringExtra("fats");
        String ingredients = getIntent().getStringExtra("ingredients");
        String preparation = getIntent().getStringExtra("preparation");
        String cooking = getIntent().getStringExtra("cooking");
        String photo = getIntent().getStringExtra("image");

        ImageView imageView = findViewById(R.id.DishImageView);
        TextView DishNameTextView = findViewById(R.id.DishNameTextView);
        TextView TimeText = findViewById(R.id.time);
        TextView CaloriesText = findViewById(R.id.calories);
        TextView FatsText = findViewById(R.id.fats);
        TextView CookingTextView = findViewById(R.id.cooking);
        TextView IngredientsTextView = findViewById(R.id.ingredients);
        TextView PreparationTextView = findViewById(R.id.preparation);

        TimeText.setText(time);
        CaloriesText.setText(calories);
        FatsText.setText(fats);

        IngredientsTextView.setText(ingredients);
        PreparationTextView.setText(preparation);
        CookingTextView.setText(cooking);

        Glide.with(this).load(photo).into(imageView);
        DishNameTextView.setText(name);

//        dishes = new ArrayList<>();
//
//        items_recycler = findViewById(R.id.itemsRecyclerView);
//        fetchIngredients();
//        senddetaills();
//
//        adapter = new DishesRecyclerAdapter(dishes, getApplicationContext());
//        items_recycler.setAdapter(adapter);
//        items_recycler.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
//
//
//        ImageView erase_button = findViewById(R.id.erase_button);
//        EditText SearchEdit = findViewById(R.id.search_edit_text);
//        SearchEdit.addTextChangedListener(new TextWatcher() {
//
//            @Override
//            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
//
//            }
//
//            public void onTextChanged(CharSequence s, int start,
//                                      int before, int count) {
//
//            }
//
//            @Override
//            public void afterTextChanged(Editable editable) {
//                String strCHR = SearchEdit.getText().toString();
//                if (SearchEdit.getText().toString().length() > 0) {
//                    erase_button.setVisibility(View.VISIBLE);
//                    ArrayList<Dishes> listNew = new ArrayList<>();
//                    for (int l = 0; l < dishes.size(); l++) {
//                        String serviceName = dishes.get(l).getName().toLowerCase();
//                        if (serviceName.contains(strCHR.toLowerCase())) {
//                            listNew.add(dishes.get(l));
//                        }
//                    }
//                    items_recycler.setVisibility(View.VISIBLE);
//                    adapter = new DishesRecyclerAdapter(listNew, getApplicationContext());
//                } else {
//                    erase_button.setVisibility(View.GONE);
//                    items_recycler.setVisibility(View.VISIBLE);
//                    adapter = new DishesRecyclerAdapter(dishes, getApplicationContext());
//                }
//                items_recycler.setAdapter(adapter);
//            }
//        });
//
//        erase_button.setOnClickListener(view -> {
//            SearchEdit.setText("");
//        });


    }
}