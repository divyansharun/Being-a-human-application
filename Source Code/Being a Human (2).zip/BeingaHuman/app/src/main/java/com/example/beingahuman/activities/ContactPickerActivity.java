package com.example.beingahuman.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.widget.Toast;

import com.example.beingahuman.R;
import com.example.beingahuman.classes.Contact;
import com.example.beingahuman.classes.ContactLab;

import java.util.ArrayList;
import java.util.List;


public class ContactPickerActivity extends AppCompatActivity {

    private static final int PICK_CONTACT = 137;
    Contact mContact;

    private static final String ARG_CONTACT = "contact";
    private static final String ARG_REQUEST_TYPE = "request_type";
    private static final String DIALOG_CONTACT_IMAGE = "DialogContactImage";
    public static final String CONTACT_OBJECT = "contactObject";
    private static final int REQUEST_PHOTO= 0;
    public static final int ADD_CONTACT = 0;
    public static final int UPDATE_CONTACT = 1;
    public static final String RETURN_STATE = "contactState";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_picker);

        mContact = new Contact();

        Intent intent = new Intent(Intent.ACTION_PICK, ContactsContract.Contacts.CONTENT_URI);
        startActivityForResult(intent,PICK_CONTACT );//PICK_CONTACT is private static final int, so declare in activity class
    }

    public void onActivityResult(int reqCode, int resultCode, Intent data)
    {
        super.onActivityResult(reqCode, resultCode, data);

        switch(reqCode){
            case (PICK_CONTACT):
                if (resultCode == Activity.RESULT_OK)
                {
                    Uri contactData = data.getData();
                    Cursor c = managedQuery(contactData, null, null, null, null);
                    if (c.moveToFirst()) {
                        String id =
                                c.getString(c.getColumnIndexOrThrow(ContactsContract.Contacts._ID));

                        String hasPhone =
                                c.getString(c.getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER));

                        if (hasPhone.equalsIgnoreCase("1")) {
                            Cursor phones = getContentResolver().query(
                                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,null,
                                    ContactsContract.CommonDataKinds.Phone.CONTACT_ID +" = "+ id,
                                    null, null);
                            phones.moveToFirst();
                            String phn_no = phones.getString(phones.getColumnIndex("data1"));
                            String name = c.getString(c.getColumnIndex(ContactsContract.CommonDataKinds.StructuredPostal.DISPLAY_NAME));

                            mContact.setName(name);
                            List<String> newPhones = new ArrayList<>();

                            newPhones.add(phn_no);

                            mContact.setPhones(newPhones);


                            ContactLab.get(this).addContact(mContact);

                            Intent resultIntent = new Intent();
                            resultIntent.putExtra(RETURN_STATE, "1");
                            resultIntent.putExtra(CONTACT_OBJECT, mContact);
                            this.setResult(Activity.RESULT_OK, resultIntent);

                            this.finish();

                            Toast.makeText(this, "contact info : "+ phn_no+"\n"+name, Toast.LENGTH_LONG).show();

                        }
                    }
                }
        }
    }

}