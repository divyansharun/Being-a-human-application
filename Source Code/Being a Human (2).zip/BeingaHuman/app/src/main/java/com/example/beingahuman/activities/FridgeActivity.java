package com.example.beingahuman.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.example.beingahuman.R;
import com.example.beingahuman.adapters.IngredientRecyclerAdapter;

import static com.example.beingahuman.Utils.SQLCodes.CREATE_DRAWERS_TABLE;
import static com.example.beingahuman.Utils.SQLCodes.CREATE_EVENTS_TABLE;
import static com.example.beingahuman.Utils.SQLCodes.CREATE_FRIDGE_TABLE;
import static com.example.beingahuman.Utils.SQLCodes.CREATE_OUTFITS_TABLE;
import static com.example.beingahuman.Utils.SQLCodes.CREATE_WEARS_TABLE;

public class FridgeActivity extends AppCompatActivity {

    RelativeLayout fridge_button, recipe_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fridge);

        fridge_button = findViewById(R.id.fridge_button);
        recipe_button = findViewById(R.id.recipe_button);

        fridge_button.setOnClickListener( v -> goToFridge());
        recipe_button.setOnClickListener( v -> goToRecipe());

        createDatabaseIfNotExists();

    }

    private void goToFridge() {
        startActivity(new Intent(this, IngredientsActivity.class));
    }

    private void goToRecipe() {
        startActivity(new Intent(this, RecipeActivity.class));
    }

    private void createDatabaseIfNotExists() {
        SQLiteDatabase db = null;
        try {
            db = openOrCreateDatabase("Database", MODE_PRIVATE, null);
            db.execSQL(CREATE_FRIDGE_TABLE);
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), "An error occurred!", Toast.LENGTH_SHORT).show();
        } finally {
            if (db != null) db.close();
        }
    }
}