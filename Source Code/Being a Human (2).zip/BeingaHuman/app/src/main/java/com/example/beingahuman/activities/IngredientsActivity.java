package com.example.beingahuman.activities;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.beingahuman.R;
import com.example.beingahuman.adapters.IngredientRecyclerAdapter;
import com.example.beingahuman.models.Ingredient;
import static com.example.beingahuman.Utils.IngredientTypes.FRUITS;
import static com.example.beingahuman.Utils.IngredientTypes.VEGETABLES;
import static com.example.beingahuman.Utils.IngredientTypes.DAIRY_PRODUCTS;
import static com.example.beingahuman.Utils.IngredientTypes.MUSHROOMS;

import com.google.android.material.chip.Chip;

import java.util.ArrayList;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;
import static android.widget.Toast.LENGTH_SHORT;

public class IngredientsActivity extends AppCompatActivity {
    private RecyclerView wearsRecycler;
    private TextView noItemText;
    private ArrayList<Ingredient> ingredients;
    LinearLayout add_button;
    Chip all_chip, veg_chip, dairy_chip, mush_chip, fruit_chip;
    int fetch_type;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initialize();
    }

    private void initialize() {
        setContentView(R.layout.activity_ingredients);

        Window window = this.getWindow();
        View vieww = window.getDecorView();

        new WindowInsetsControllerCompat(window,vieww).setAppearanceLightStatusBars(true);

        fetch_type = -1;

        wearsRecycler = findViewById(R.id.wearsRecyclerView);
        noItemText = findViewById(R.id.noItemText);
        add_button = findViewById(R.id.add_button);
        all_chip = findViewById(R.id.chip_all);
        veg_chip = findViewById(R.id.chip_veg);
        dairy_chip = findViewById(R.id.chip_dairy);
        fruit_chip = findViewById(R.id.chip_fruits);
        mush_chip = findViewById(R.id.chip_mush);
        add_button.setOnClickListener(view -> {
            Intent intent = new Intent(this, NewIngredientActivity.class);
            startActivity(intent);
        });

        all_chip.setOnClickListener(view -> {
            fetch_type = -1;
            fetchWears();
        });
        veg_chip.setOnClickListener(view -> {
            fetch_type = VEGETABLES;
            fetchWears();
        });
        fruit_chip.setOnClickListener(view -> {
            fetch_type = FRUITS;
            fetchWears();
        });
        dairy_chip.setOnClickListener(view -> {
            fetch_type = DAIRY_PRODUCTS;
            fetchWears();
        });
        mush_chip.setOnClickListener(view -> {
            fetch_type = MUSHROOMS;
            fetchWears();
        });

        ImageView back_button = findViewById(R.id.back_button);

        back_button.setOnClickListener(view -> {
            onBackPressed();
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        fetchWears();
    }

//    @Override
//    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
//        Intent intent = new Intent(this, CreateWearActivity.class);
//        intent.putExtra("id", getIntent().getIntExtra("id", -1));
//        startActivity(intent);
//        return true;
//    }

    public void fetchWears() {
        ingredients = new ArrayList<Ingredient>();
        SQLiteDatabase db = null;
        Cursor cursor = null;
        try {
            db = openOrCreateDatabase("Database", MODE_PRIVATE, null);
            if (fetch_type == -1){
                cursor = db.rawQuery("SELECT * FROM fridge", null);
            }else {
                cursor = db.rawQuery("SELECT * FROM fridge WHERE type =" + fetch_type, null);
            }
            while (cursor.moveToNext()) {
                int id = cursor.getInt(cursor.getColumnIndex("id"));
                int i_id = cursor.getInt(cursor.getColumnIndex("i_id"));
                String name = cursor.getString(cursor.getColumnIndex("name"));
                int type = cursor.getInt(cursor.getColumnIndex("type"));
                String photo = Uri.parse(Uri.decode(cursor.getString(cursor.getColumnIndex("photo")))).toString();
                Ingredient ingredient = new Ingredient(id, i_id, name, type, photo);
                ingredients.add(ingredient);
            }
        } catch (Exception e) {
            Toast.makeText(this, "Something went wrong!", LENGTH_SHORT);
        } finally {
            if (cursor != null) cursor.close();
            if (db != null) db.close();
            IngredientRecyclerAdapter adapter = new IngredientRecyclerAdapter(ingredients, this);
            wearsRecycler.setAdapter(adapter);
            wearsRecycler.setLayoutManager(new GridLayoutManager(this, 2));
            adapter.notifyDataSetChanged();
            noItemText.setVisibility(ingredients.size() == 0 ? VISIBLE : GONE);
        }
    }
}