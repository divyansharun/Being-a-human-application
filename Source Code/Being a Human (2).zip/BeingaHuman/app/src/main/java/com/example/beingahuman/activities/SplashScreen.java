package com.example.beingahuman.activities;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.preference.PreferenceManager;

import com.example.beingahuman.R;

public class SplashScreen extends AppCompatActivity {
    SplashScreen activity;
    Context context;
    ImageView logo;
    Animation slide_up,fade_in;
    AnimationSet s;
    RelativeLayout main_splash;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);
        context = activity = this;
//        main_splash = findViewById(R.id.main_splash);



//        appUpdateManager = AppUpdateManagerFactory.create(context);
        HomeScreen();

    }

//    @Override
//    protected void onResume() {
//        super.onResume();
//        activity = this;
//
//        appUpdateManager.getAppUpdateInfo().addOnSuccessListener(appUpdateInfo -> {
//            if (appUpdateInfo.updateAvailability() == UpdateAvailability.DEVELOPER_TRIGGERED_UPDATE_IN_PROGRESS) {
//                try {
//                    appUpdateManager.startUpdateFlowForResult(
//                            appUpdateInfo, IMMEDIATE, activity, 101);
//                } catch (IntentSender.SendIntentException e) {
//                    e.printStackTrace();
//                }
//            }
//        });
//    }

    public void HomeScreen() {
        if (restorePreData()){
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    Intent mainActivity = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(mainActivity);
                    finish();
                }
            }, 1000);
        }else {
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    Intent i = new Intent(SplashScreen.this, IntroActivity.class);
                    startActivity(i);
                }
            }, 1000);
        }

    }

    public void UpdateApp() {
//        try {
//            Task<AppUpdateInfo> appUpdateInfoTask = appUpdateManager.getAppUpdateInfo();
//            appUpdateInfoTask.addOnSuccessListener(appUpdateInfo -> {
//                if (appUpdateInfo.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE
//                        && appUpdateInfo.isUpdateTypeAllowed(IMMEDIATE)) {
//                    try {
//                        appUpdateManager.startUpdateFlowForResult(
//                                appUpdateInfo, IMMEDIATE, activity, 101);
//                    } catch (IntentSender.SendIntentException e) {
//                        e.printStackTrace();
//                    }
//                } else {
//                    HomeScreen();
//                }
//            }).addOnFailureListener(e -> {
//                e.printStackTrace();
//                HomeScreen();
//            });
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 101) {
            if (resultCode != RESULT_OK) {
                HomeScreen();
            } else {
                HomeScreen();
            }
        }
    }


    private boolean restorePreData(){
        SharedPreferences preferences =  PreferenceManager.getDefaultSharedPreferences(this);
        return preferences.getBoolean("isIntroOpened", false);
    }


}
