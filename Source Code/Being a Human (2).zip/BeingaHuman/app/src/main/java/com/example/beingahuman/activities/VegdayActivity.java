package com.example.beingahuman.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.preference.PreferenceManager;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.beingahuman.R;
import com.google.android.material.bottomsheet.BottomSheetBehavior;

import java.text.SimpleDateFormat;
import java.util.Date;

public class VegdayActivity extends AppCompatActivity {

    TextView day, day_desc;
    ImageView food_icon, back_button;
    Button nearby_restaurants;
    String monday,tuesday,wednesday,thursday,friday,saturday,sunday;

    BottomSheetBehavior bottomSheetBehavior;
    RadioButton buttonmondayveg,buttonmondaynon,
            buttontuesdayveg,buttontuesdaynon,
            buttonwednesdayveg, buttonwednesdaynon,
            buttonthursdayveg, buttonthursdaynon,
            buttonfridayveg, buttonfridaynon,
            buttonsaturdayveg, buttonsaturdaynon,
            buttonsundayveg, buttonsundaynon;

    String dayOfTheWeek;
    Date d;
    SimpleDateFormat sdf;
    SharedPreferences preferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vegday);

        Window window = this.getWindow();
        View vieww = window.getDecorView();

        new WindowInsetsControllerCompat(window,vieww).setAppearanceLightStatusBars(true);

        day = findViewById(R.id.day);
        food_icon = findViewById(R.id.food_icon);
        day_desc = findViewById(R.id.day_desc);
        nearby_restaurants = findViewById(R.id.nearby_restaurants);
        back_button = findViewById(R.id.back_button);
        back_button.setOnClickListener(view -> onBackPressed());

        preferences = PreferenceManager.getDefaultSharedPreferences(this);


        View bottomsheet = findViewById(R.id.bottom_sheet);
        bottomSheetBehavior = BottomSheetBehavior.from(bottomsheet);

        RelativeLayout edit_days = findViewById(R.id.arrow);
        edit_days.setOnClickListener(view -> bottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED));

        buttonmondayveg = findViewById(R.id.monday_veg);
        buttonmondaynon = findViewById(R.id.monday_non);

        buttontuesdayveg = findViewById(R.id.tuesday_veg);
        buttontuesdaynon = findViewById(R.id.tuesday_non);

        buttonwednesdayveg = findViewById(R.id.wednesday_veg);
        buttonwednesdaynon = findViewById(R.id.wednesday_non);

        buttonthursdayveg = findViewById(R.id.thursday_veg);
        buttonthursdaynon = findViewById(R.id.thursday_non);

        buttonfridayveg = findViewById(R.id.friday_veg);
        buttonfridaynon = findViewById(R.id.friday_non);

        buttonsaturdayveg = findViewById(R.id.saturday_veg);
        buttonsaturdaynon = findViewById(R.id.saturday_non);

        buttonsundayveg = findViewById(R.id.sunday_veg);
        buttonsundaynon = findViewById(R.id.sunday_non);

        sdf = new SimpleDateFormat("EEEE");
        d = new Date();
        dayOfTheWeek = sdf.format(d);

        setup();

        Uri gmmIntentUri = Uri.parse("geo:0,0?q=restaurants");
        Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
        mapIntent.setPackage("com.google.android.apps.maps");

        nearby_restaurants.setOnClickListener(view -> startActivity(mapIntent));
    }

    public void setup(){

        int custom_food = preferences.getInt("custom_days_food", 0);

        if(custom_food == 1){

            String today_day = preferences.getString("food_"+dayOfTheWeek.toLowerCase(), "veg");

            assert today_day != null;
            if (today_day.equals("non")){
                day.setText("It's a Non-Veg day");
                day_desc.setText("It's a Non-Veg day, get yourself a good protein rich food.");
                food_icon.setImageResource(R.drawable.ic_undraw_breakfast_psiw);
            }else{
                day.setText("It's a Veg day");
                day_desc.setText("It's a Veg day, get yourself some refreshing vegetarian food.");
                food_icon.setImageResource(R.drawable.ic_undraw_hamburger_8ge6);
            }

        }else {

            if (dayOfTheWeek.equals("Monday") || dayOfTheWeek.equals("Wednesday") || dayOfTheWeek.equals("Friday") || dayOfTheWeek.equals("Saturday") || dayOfTheWeek.equals("Sunday")) {
                day.setText("It's a Non-Veg day");
                day_desc.setText("It's a Non-Veg day, get yourself a good protein rich food.");
                food_icon.setImageResource(R.drawable.ic_undraw_breakfast_psiw);
            }else{
                day.setText("It's a Veg day");
                day_desc.setText("It's a Veg day, get yourself some refreshing vegetarian food.");
                food_icon.setImageResource(R.drawable.ic_undraw_hamburger_8ge6);
            }

        }

        if(custom_food == 1){

            String mon = preferences.getString("food_monday", "non");
            String tue = preferences.getString("food_tuesday", "veg");
            String wed = preferences.getString("food_wednesday", "non");
            String thr = preferences.getString("food_thursday", "veg");
            String fri = preferences.getString("food_friday", "non");
            String sat = preferences.getString("food_saturday", "non");
            String sun = preferences.getString("food_sunday", "non");

            if(mon.equals("veg")){
                buttonmondayveg.setChecked(true);
            }else {
                buttonmondaynon.setChecked(true);
            }

            if(tue.equals("veg")){
                buttontuesdayveg.setChecked(true);
            }else {
                buttontuesdaynon.setChecked(true);
            }

            if(wed.equals("veg")){
                buttonwednesdayveg.setChecked(true);
            }else {
                buttonwednesdaynon.setChecked(true);
            }

            if(thr.equals("veg")){
                buttonthursdayveg.setChecked(true);
            }else {
                buttonthursdaynon.setChecked(true);
            }

            if(fri.equals("veg")){
                buttonfridayveg.setChecked(true);
            }else {
                buttonfridaynon.setChecked(true);
            }

            if(sat.equals("veg")){
                buttonsaturdayveg.setChecked(true);
            }else {
                buttonsaturdaynon.setChecked(true);
            }

            if(sun.equals("veg")){
                buttonsundayveg.setChecked(true);
            }else {
                buttonsundaynon.setChecked(true);
            }

        }else {

            buttontuesdayveg.setChecked(true);
            buttonthursdayveg.setChecked(true);
            buttonmondaynon.setChecked(true);
            buttonwednesdaynon.setChecked(true);
            buttonfridaynon.setChecked(true);
            buttonsaturdaynon.setChecked(true);
            buttonsundaynon.setChecked(true);

        }

        Button submit_button = findViewById(R.id.editdays_submit);

        submit_button.setOnClickListener(view -> {

            if (buttonmondayveg.isChecked()){
                monday = "veg";
            }
            if(buttonmondaynon.isChecked()){
                monday = "non";
            }

            if(buttontuesdayveg.isChecked()){
                tuesday = "veg";
            }
            if(buttontuesdaynon.isChecked()){
                tuesday = "non";
            }

            if(buttonwednesdayveg.isChecked()){
                wednesday = "veg";
            }
            if(buttonwednesdaynon.isChecked()){
                wednesday = "non";
            }

            if(buttonthursdayveg.isChecked()){
                thursday = "veg";
            }
            if(buttonthursdaynon.isChecked()){
                thursday = "non";
            }

            if(buttonfridayveg.isChecked()){
                friday = "veg";
            }
            if(buttonfridaynon.isChecked()){
                friday = "non";
            }

            if(buttonsaturdayveg.isChecked()){
                saturday = "veg";
            }
            if(buttonsaturdaynon.isChecked()){
                saturday = "non";
            }

            if(buttonsundayveg.isChecked()){
                sunday = "veg";
            }
            if(buttonsundaynon.isChecked()){
                sunday = "non";
            }

            preferences.edit().putString("food_monday", monday).apply();
            preferences.edit().putString("food_tuesday", tuesday).apply();
            preferences.edit().putString("food_wednesday", wednesday).apply();
            preferences.edit().putString("food_thursday", thursday).apply();
            preferences.edit().putString("food_friday", friday).apply();
            preferences.edit().putString("food_saturday", saturday).apply();
            preferences.edit().putString("food_sunday", sunday).apply();
            preferences.edit().putInt("custom_days_food", 1).apply();

            bottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);

            setup();

        });



    }

}