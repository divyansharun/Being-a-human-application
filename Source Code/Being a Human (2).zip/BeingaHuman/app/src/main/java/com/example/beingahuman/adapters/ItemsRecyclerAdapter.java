package com.example.beingahuman.adapters;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;

import com.bumptech.glide.Glide;
import com.example.beingahuman.R;
import com.example.beingahuman.activities.EditWearActivity;
import com.example.beingahuman.activities.IngredientsActivity;
import com.example.beingahuman.models.Ingredient;
import com.example.beingahuman.models.Items;
import com.example.beingahuman.models.TempIngredient;

import java.util.ArrayList;

import static android.content.Context.MODE_PRIVATE;
import static android.widget.Toast.LENGTH_SHORT;
import static com.example.beingahuman.Utils.IngredientTypes.INGREDIENT_TYPES;

public class ItemsRecyclerAdapter extends RecyclerView.Adapter<ItemsRecyclerAdapter.WearViewHolder> {
    private final ArrayList<Items> items;
    private final ArrayList<TempIngredient> ingredients;
    private final Context context;

    public ItemsRecyclerAdapter(ArrayList<Items> items, ArrayList<TempIngredient> ingredients, Context context) {
        this.ingredients = ingredients;
        this.items = items;
        this.context = context;
    }

    @NonNull
    @Override
    public WearViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.single_item_item, parent, false);
        return new ItemsRecyclerAdapter.WearViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull WearViewHolder holder, int position) {
        Items item = items.get(position);
        Glide.with(context).load(item.getPhoto()).into(holder.wearItemImageView);
//        holder.wearItemImageView.setImageBitmap(ingredient.getPhoto());
        holder.wearItemNameTextView.setText(item.getName());
        holder.wearItemTypeTextView.setText(INGREDIENT_TYPES[item.getType()]);
        if(ingredients.size()>0) {
            for (int i = 0; i < ingredients.size(); i++) {
                TempIngredient ingredient = ingredients.get(i);
                Log.d("Print", ingredient.getI_id() + " " + item.getId());
                if (ingredient.getI_id() == item.getId()) {
                    holder.wearItemRemoveIcon.setVisibility(View.GONE);
                    holder.added_icon.setVisibility(View.VISIBLE);
                } else {
                    holder.wearItemRemoveIcon.setOnClickListener(view -> {
                        addItemToFridge(item.getId(), item.getName(), item.getType(), item.getPhoto());
                        holder.wearItemRemoveIcon.setVisibility(View.GONE);
                        holder.added_icon.setVisibility(View.VISIBLE);
                    });
                }
            }
        }else{
            holder.wearItemRemoveIcon.setOnClickListener(view -> {
                addItemToFridge(item.getId(), item.getName(), item.getType(), item.getPhoto());
                holder.wearItemRemoveIcon.setVisibility(View.GONE);
                holder.added_icon.setVisibility(View.VISIBLE);
            });
        }

    }

    private void goToEditWear(int id) {
        Intent intent = new Intent(context, EditWearActivity.class);
        intent.putExtra("id", id);
        context.startActivity(intent);
    }

    private void removeIngredient(int id) {
        SQLiteDatabase db = null;
        String message = null;
        try {
            db = context.openOrCreateDatabase("Database", MODE_PRIVATE, null);
            db.execSQL("DELETE FROM fridge WHERE id = " + id);
            message = "The items has been successfully deleted!";
        } catch (Exception e) {
            message = "Something went wrong!";
        } finally {
            if (db != null) db.close();
            Toast.makeText(context, message, LENGTH_SHORT).show();
            ((IngredientsActivity) context).fetchWears();
        }
    }

    private void addItemToFridge(int id, String name, int type, String image_url) {
        SQLiteDatabase db = null;
        String message = null;
        try {
            db = context.openOrCreateDatabase("Database", MODE_PRIVATE, null);
            String sql = "INSERT INTO fridge (i_id, name, type, photo) VALUES (?, ?, ?, ?)";
            SQLiteStatement statement = db.compileStatement(sql);
            statement.bindLong(1, id);
            statement.bindString(2, name);
            statement.bindLong(3, type);
            statement.bindString(4, image_url);
            statement.executeInsert();
            message = "Item successfully added!";
        } catch (Exception e) {
            e.printStackTrace();
            message = "Something went wrong!";
        } finally {
            if (db != null) db.close();
            Toast.makeText(context, message, LENGTH_SHORT).show();
        }
    }

    @Override
    public int getItemCount() { return items.size(); }

    public class WearViewHolder extends ViewHolder {
        private CardView itemCardView;
        private ImageView wearItemImageView;
        private ImageView wearItemRemoveIcon;
        private ImageView added_icon;
        private TextView wearItemNameTextView;
        private TextView wearItemTypeTextView;
        private TextView wearItemColorPatternTextView;
        private TextView wearItemPriceTextView;
        private TextView wearItemPurchaseDateTextView;

        public WearViewHolder(@NonNull View itemView) {
            super(itemView);
            itemCardView = itemView.findViewById(R.id.itemCardView);
            wearItemImageView = itemView.findViewById(R.id.wearItemImageView);
            wearItemRemoveIcon = itemView.findViewById(R.id.wearItemRemoveIcon);
            added_icon = itemView.findViewById(R.id.added_icon);
            wearItemNameTextView = itemView.findViewById(R.id.wearItemNameTextView);
            wearItemTypeTextView = itemView.findViewById(R.id.wearItemTypeTextView);
            wearItemColorPatternTextView = itemView.findViewById(R.id.wearItemColorPatternTextView);
            wearItemPriceTextView = itemView.findViewById(R.id.wearItemPriceTextView);
            wearItemPurchaseDateTextView = itemView.findViewById(R.id.wearItemPurchaseDateTextView);
        }
    }
}
