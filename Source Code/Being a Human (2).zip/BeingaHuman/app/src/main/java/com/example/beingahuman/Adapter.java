package com.example.beingahuman;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityOptionsCompat;
import androidx.core.util.Pair;
import androidx.recyclerview.widget.RecyclerView;

import com.example.beingahuman.activities.FridgeActivity;
import com.example.beingahuman.activities.LovedOnesActivity;
import com.example.beingahuman.activities.ExpenseActivity;
import com.example.beingahuman.activities.MedicineActivity;
import com.example.beingahuman.periodical.PeriodActivity;
import com.example.beingahuman.activities.SalonActivity;
import com.example.beingahuman.activities.TodoActivity;
import com.example.beingahuman.activities.VegdayActivity;
import com.example.beingahuman.activities.WardrobeActivity;
import com.example.beingahuman.activities.WaterActivity;
import com.example.beingahuman.activities.WeatherActivity;

public class Adapter extends RecyclerView.Adapter<Adapter.MyAdapter> {
    Context context;

    public Adapter(Context context) {
        this.context = context;
    }

    @NonNull
    @Override
    public MyAdapter onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.row,parent,false);
        return new MyAdapter(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyAdapter holder, int position) {
        if(position==0)
        {
            holder.image1.setImageResource(R.drawable.undraw_online_groceries_a02y);
            holder.back.setBackgroundColor(Color.parseColor("#A8F9FAFC"));
            holder.text.setText("What's in my Fridge?");
        }
        if(position==1)
        {
            holder.image1.setImageResource(R.drawable.ic_undraw_barber_3uel);
            holder.back.setBackgroundColor(Color.parseColor("#A8F9FAFC"));
            holder.text.setText("Salon day");
        }
        if(position==2)
        {
            holder.image1.setImageResource(R.drawable.ic_undraw_breakfast_psiw);
            holder.back.setBackgroundColor(Color.parseColor("#A8F9FAFC"));
            holder.text.setText("Food day");
        }
        if(position==3)
        {
            holder.image1.setImageResource(R.drawable.undraw_refreshing);
            holder.back.setBackgroundColor(Color.parseColor("#A8F9FAFC"));
            holder.text.setText("Water reminder");
        }
        if(position==4){
            holder.image1.setImageResource(R.drawable.undraw_meditation);
            holder.back.setBackgroundColor(Color.parseColor("#A8F9FAFC"));
            holder.text.setText("Female health");
        }
        if(position==5)
        {
            holder.image1.setImageResource(R.drawable.ic_undraw_window_shopping_re_0kbm);
            holder.back.setBackgroundColor(Color.parseColor("#A8F9FAFC"));
            holder.text.setText("Wardrobe");
        }
        if(position==6)
        {
            holder.image1.setImageResource(R.drawable.undraw_to_do_list);
            holder.back.setBackgroundColor(Color.parseColor("#A8F9FAFC"));
            holder.text.setText("Todo list");
        }
        if(position==7)
        {
            holder.image1.setImageResource(R.drawable.medicines);
            holder.back.setBackgroundColor(Color.parseColor("#A8F9FAFC"));
            holder.text.setText("Medications");
        }
        if(position==8){
            holder.image1.setImageResource(R.drawable.loved_ones);
            holder.back.setBackgroundColor(Color.parseColor("#A8F9FAFC"));
            holder.text.setText("Hi your loved ones");
        }
        if(position==9)
        {
            holder.image1.setImageResource(R.drawable.undraw_calculator);
            holder.back.setBackgroundColor(Color.parseColor("#A8F9FAFC"));
            holder.text.setText("Expense account");
        }
        if(position==10)
        {
            holder.image1.setImageResource(R.drawable.undraw_weather_notification);
            holder.back.setBackgroundColor(Color.parseColor("#A8F9FAFC"));
            holder.text.setText("Laundry check");
        }

        holder.parent_card.setOnClickListener(view -> {
            Intent myIntent = null;

//            Toast.makeText(context,"Click on item: " + position,Toast.LENGTH_SHORT).show();
            if(position==0)
            {
                myIntent = new Intent(context, FridgeActivity.class);

            }
            if(position==1)
            {
                myIntent = new Intent(context, SalonActivity.class);

            }
            if(position==2)
            {
                myIntent = new Intent(context, VegdayActivity.class);

            }
            if(position==3)
            {
                myIntent = new Intent(context, WaterActivity.class);

            }
            if(position==4)
            {
                myIntent = new Intent(context, PeriodActivity.class);

            }
            if(position==5)
            {

                myIntent = new Intent(context, WardrobeActivity.class);

            }
            if(position==6)
            {

                myIntent = new Intent(context, TodoActivity.class);

            }
            if(position==7)
            {

                myIntent = new Intent(context, MedicineActivity.class);

            }
            if(position==8)
            {

                myIntent = new Intent(context, LovedOnesActivity.class);

            }
            if(position==9)
            {

                myIntent = new Intent(context, ExpenseActivity.class);

            }
            if(position==10)
            {
                myIntent = new Intent(context, WeatherActivity.class);

            }
            if (myIntent != null) {
                Pair<View, String> p1 = Pair.create(holder.parent_card, "activity");
                ActivityOptionsCompat options = ActivityOptionsCompat.makeSceneTransitionAnimation((Activity) context, p1);
                context.startActivity(myIntent, options.toBundle());
            }
        });

    }
    @Override
    public int getItemCount() {
        return 11;
    }
    public static class MyAdapter extends RecyclerView.ViewHolder {
        CardView parent_card;
        ImageView image,image1;
        TextView text;
        RelativeLayout back;
        public MyAdapter(@NonNull View itemView) {
            super(itemView);
            parent_card= itemView.findViewById(R.id.parent_card);
            image=itemView.findViewById(R.id.image);
            image1=itemView.findViewById(R.id.image1);
            text=itemView.findViewById(R.id.text);
            back=itemView.findViewById(R.id.back);
        }
    }
}
