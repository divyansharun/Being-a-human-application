package com.example.beingahuman.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.preference.PreferenceManager;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.beingahuman.R;
import com.google.android.material.bottomsheet.BottomSheetBehavior;

import java.text.SimpleDateFormat;
import java.util.Date;

public class SalonActivity extends AppCompatActivity {

    TextView day, day_desc;
    ImageView salon_icon, back_button;
    Button nearby_salons;

    String monday,tuesday,wednesday,thursday,friday,saturday,sunday;

    RadioButton buttonmondayyes,buttonmondayno,
            buttontuesdayyes,buttontuesdayno,
            buttonwednesdayyes, buttonwednesdayno,
            buttonthursdayyes, buttonthursdayno,
            buttonfridayyes, buttonfridayno,
            buttonsaturdayyes, buttonsaturdayno,
            buttonsundayyes, buttonsundayno;

    BottomSheetBehavior bottomSheetBehavior;

    String dayOfTheWeek;
    Date d;
    SimpleDateFormat sdf;
    SharedPreferences preferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_salon);

        Window window = this.getWindow();
        View vieww = window.getDecorView();

        new WindowInsetsControllerCompat(window,vieww).setAppearanceLightStatusBars(true);

        day = findViewById(R.id.day);
        salon_icon = findViewById(R.id.salon_icon);
        day_desc = findViewById(R.id.day_desc);
        nearby_salons = findViewById(R.id.nearby_salons);
        back_button = findViewById(R.id.back_button);
        back_button.setOnClickListener(view -> onBackPressed());

        preferences = PreferenceManager.getDefaultSharedPreferences(this);


        View bottomsheet = findViewById(R.id.bottom_sheet);
        bottomSheetBehavior = BottomSheetBehavior.from(bottomsheet);

        RelativeLayout edit_days = findViewById(R.id.arrow);
        edit_days.setOnClickListener(view -> bottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED));

        buttonmondayyes = findViewById(R.id.monday_yes);
        buttonmondayno = findViewById(R.id.monday_no);

        buttontuesdayyes = findViewById(R.id.tuesday_yes);
        buttontuesdayno = findViewById(R.id.tuesday_no);

        buttonwednesdayyes = findViewById(R.id.wednesday_yes);
        buttonwednesdayno = findViewById(R.id.wednesday_no);

        buttonthursdayyes = findViewById(R.id.thursday_yes);
        buttonthursdayno = findViewById(R.id.thursday_no);

        buttonfridayyes = findViewById(R.id.friday_yes);
        buttonfridayno = findViewById(R.id.friday_no);

        buttonsaturdayyes = findViewById(R.id.saturday_yes);
        buttonsaturdayno = findViewById(R.id.saturday_no);

        buttonsundayyes = findViewById(R.id.sunday_yes);
        buttonsundayno = findViewById(R.id.sunday_no);

        sdf = new SimpleDateFormat("EEEE");
        d = new Date();
        dayOfTheWeek = sdf.format(d);

        setup();

        Uri gmmIntentUri = Uri.parse("geo:0,0?q=salons");
        Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
        mapIntent.setPackage("com.google.android.apps.maps");

        nearby_salons.setOnClickListener(view -> startActivity(mapIntent));

    }

    public void setup(){

        int custom_hair = preferences.getInt("custom_days_hair", 0);

        if(custom_hair == 1){

            String today_day = preferences.getString("hair_"+dayOfTheWeek.toLowerCase(), "yes");

            assert today_day != null;
            if (today_day.equals("no")){
                day.setText("It's not a salon day");
                day_desc.setText("It's not a salon day, you can get your favourite haircut tomorrow.");
                salon_icon.setImageResource(R.drawable.ic_undraw_relaxing_at_home_re_mror);

                nearby_salons.setVisibility(View.GONE);
            }else{
                day.setText("It's a Salon day");
                day_desc.setText("It's a Salon day, you can get your favourite haircut today.");
                salon_icon.setImageResource(R.drawable.ic_undraw_barber_3uel);

                nearby_salons.setVisibility(View.VISIBLE);
            }

        }else {

            if(dayOfTheWeek.equals("Monday") || dayOfTheWeek.equals("Wednesday") || dayOfTheWeek.equals("Friday") || dayOfTheWeek.equals("Sunday")){
                day.setText("It's a Salon day");
                day_desc.setText("It's a Salon day, you can get your favourite haircut today.");
                salon_icon.setImageResource(R.drawable.ic_undraw_barber_3uel);

                nearby_salons.setVisibility(View.VISIBLE);
            }else{
                day.setText("It's not a salon day");
                day_desc.setText("It's not a salon day, you can get your favourite haircut tomorrow.");
                salon_icon.setImageResource(R.drawable.ic_undraw_relaxing_at_home_re_mror);

                nearby_salons.setVisibility(View.GONE);
            }

        }

        if(custom_hair == 1){

            String mon = preferences.getString("hair_monday", "no");
            String tue = preferences.getString("hair_tuesday", "yes");
            String wed = preferences.getString("hair_wednesday", "no");
            String thr = preferences.getString("hair_thursday", "yes");
            String fri = preferences.getString("hair_friday", "no");
            String sat = preferences.getString("hair_saturday", "no");
            String sun = preferences.getString("hair_sunday", "no");

            if(mon.equals("yes")){
                buttonmondayyes.setChecked(true);
            }else {
                buttonmondayno.setChecked(true);
            }

            if(tue.equals("yes")){
                buttontuesdayyes.setChecked(true);
            }else {
                buttontuesdayno.setChecked(true);
            }

            if(wed.equals("yes")){
                buttonwednesdayyes.setChecked(true);
            }else {
                buttonwednesdayno.setChecked(true);
            }

            if(thr.equals("yes")){
                buttonthursdayyes.setChecked(true);
            }else {
                buttonthursdayno.setChecked(true);
            }

            if(fri.equals("yes")){
                buttonfridayyes.setChecked(true);
            }else {
                buttonfridayno.setChecked(true);
            }

            if(sat.equals("yes")){
                buttonsaturdayyes.setChecked(true);
            }else {
                buttonsaturdayno.setChecked(true);
            }

            if(sun.equals("yes")){
                buttonsundayyes.setChecked(true);
            }else {
                buttonsundayno.setChecked(true);
            }

        }else {

            buttontuesdayno.setChecked(true);
            buttonthursdayno.setChecked(true);
            buttonmondayyes.setChecked(true);
            buttonwednesdayyes.setChecked(true);
            buttonfridayyes.setChecked(true);
            buttonsaturdayno.setChecked(true);
            buttonsundayyes.setChecked(true);

        }

        Button submit_button = findViewById(R.id.editdays_submit);

        submit_button.setOnClickListener(view -> {

            if (buttonmondayyes.isChecked()){
                monday = "yes";
            }
            if(buttonmondayno.isChecked()){
                monday = "no";
            }

            if(buttontuesdayyes.isChecked()){
                tuesday = "yes";
            }
            if(buttontuesdayno.isChecked()){
                tuesday = "no";
            }

            if(buttonwednesdayyes.isChecked()){
                wednesday = "yes";
            }
            if(buttonwednesdayno.isChecked()){
                wednesday = "no";
            }

            if(buttonthursdayyes.isChecked()){
                thursday = "yes";
            }
            if(buttonthursdayno.isChecked()){
                thursday = "no";
            }

            if(buttonfridayyes.isChecked()){
                friday = "yes";
            }
            if(buttonfridayno.isChecked()){
                friday = "no";
            }

            if(buttonsaturdayyes.isChecked()){
                saturday = "yes";
            }
            if(buttonsaturdayno.isChecked()){
                saturday = "no";
            }

            if(buttonsundayyes.isChecked()){
                sunday = "yes";
            }
            if(buttonsundayno.isChecked()){
                sunday = "no";
            }

            preferences.edit().putString("hair_monday", monday).apply();
            preferences.edit().putString("hair_tuesday", tuesday).apply();
            preferences.edit().putString("hair_wednesday", wednesday).apply();
            preferences.edit().putString("hair_thursday", thursday).apply();
            preferences.edit().putString("hair_friday", friday).apply();
            preferences.edit().putString("hair_saturday", saturday).apply();
            preferences.edit().putString("hair_sunday", sunday).apply();
            preferences.edit().putInt("custom_days_hair", 1).apply();

            bottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);

            setup();

        });



    }
}