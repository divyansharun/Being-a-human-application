package com.example.beingahuman.models;


import java.io.Serializable;

public class Ingredient {
    private int id;
    private int i_id;
    private String name;
    private int type;
    private String photo;

    public Ingredient(int id, int i_id, String name, int type, String photo) {
        this.id = id;
        this.i_id = i_id;
        this.name = name;
        this.type = type;
        this.photo = photo;
    }

    public int getId() { return id; }

    public void setId(int id) { this.id = id; }

    public int getI_id() { return i_id; }

    public void setI_id(int i_id) { this.i_id = i_id; }

    public String getName() { return name; }

    public void setName(String name) { this.name = name; }

    public int getType() { return type; }

    public void setType(int type) { this.type = type; }

    public String getPhoto() { return photo; }

    public void setPhoto(String photo) { this.photo = photo; }
}
