package com.example.beingahuman.models;

public class Dishes {
    private int id;
    private String name;
    private String time;
    private String type;
    private String photo;
    private String ingredients;
    private String preparation;
    private String cooking;
    private String calories;
    private String fats;

    public Dishes(int id, String name, String time, String type, String photo, String ingredients, String preparation, String cooking, String calories, String fats) {
        this.id = id;
        this.name = name;
        this.time = time;
        this.type = type;
        this.photo = photo;
        this.ingredients = ingredients;
        this.preparation = preparation;
        this.cooking = cooking;
        this.calories = calories;
        this.fats = fats;
    }

    public int getId() { return id; }

    public void setId(int id) { this.id = id; }

    public String getName() { return name; }

    public void setName(String name) { this.name = name; }

    public String getTime() { return time; }

    public void setTime(String time) { this.time = time; }

    public String getType() { return type; }

    public void setType(String type) { this.type = type; }

    public String getIngredients() { return ingredients; }

    public void setIngredients(String ingredients) { this.ingredients = ingredients; }

    public String getPreparation() { return preparation; }

    public void setPreparation(String preparation) { this.preparation = preparation; }

    public String getCooking() { return cooking; }

    public void setCooking(String cooking) { this.cooking = cooking; }

    public String getPhoto() { return photo; }

    public void setPhoto(String photo) { this.photo = photo; }

    public String getCalories() { return calories; }

    public void setCalories(String calories) { this.calories = calories; }

    public String getFats() { return fats; }

    public void setFats(String fats) { this.fats = fats; }
}
